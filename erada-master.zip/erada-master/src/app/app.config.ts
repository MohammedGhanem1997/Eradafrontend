import {
  APP_INITIALIZER,
  ApplicationConfig,
  importProvidersFrom,
  LOCALE_ID,
  TransferState,
} from '@angular/core';
import { provideRouter, withComponentInputBinding } from '@angular/router';

import { routes } from './app.routes';
import {
  HTTP_INTERCEPTORS,
  HttpClient,
  provideHttpClient,
  withInterceptors,
} from '@angular/common/http';
import {
  LocalizeRouterModule,
  LocalizeParser,
  LocalizeRouterSettings,
  ManualParserLoader,
  CacheMechanism,
  LocalizeRouterService,
} from '@gilsdav/ngx-translate-router';
import {
  TranslateModule,
  TranslateLoader,
  TranslateService,
} from '@ngx-translate/core';
import { Location } from '@angular/common';
import { translateHttpLoaderFactory } from '@core/@utilites/translate-http-loader/translate-http.loader';
import { provideCharts, withDefaultRegisterables } from 'ng2-charts';
import { BaseChartDirective } from 'ng2-charts';
import { provideAnimations } from '@angular/platform-browser/animations';
import { AppInitializeService } from '@core/@services';
import { DynamicDialogModule } from 'primeng/dynamicdialog';
import { ErrorInterceptor } from '@core/@interceptor';
import { MessageService } from 'primeng/api';

export const appConfig: ApplicationConfig = {
  providers: [
    provideRouter(routes, withComponentInputBinding()),
    provideHttpClient(withInterceptors([ErrorInterceptor])),
    provideCharts(withDefaultRegisterables()),
    provideAnimations(),
    importProvidersFrom(
      BaseChartDirective,
      TranslateModule.forRoot({
        loader: {
          provide: TranslateLoader,
          useFactory: translateHttpLoaderFactory,
          deps: [HttpClient, TransferState],
        },
      }),
      LocalizeRouterModule.forRoot(routes, {
        parser: {
          provide: LocalizeParser,
          useFactory: (
            translate: TranslateService,
            location: Location,
            settings: LocalizeRouterSettings
          ) =>
            new ManualParserLoader(
              translate,
              location,
              settings,
              ['en', 'ar'],
              'ROUTES.'
            ),
          deps: [TranslateService, Location, LocalizeRouterSettings],
        },
        initialNavigation: true,
        cacheMechanism: CacheMechanism.Cookie,
      })
    ),
    {
      provide: LOCALE_ID,
      useValue: 'en-US',
    },
    {
      provide: APP_INITIALIZER,
      useFactory: (translate: LocalizeRouterService) => () =>
        translate.hooks.initialized,
      deps: [LocalizeRouterService],
      multi: true,
    },
    {
      provide: APP_INITIALIZER,
      useFactory: (appInitialize: AppInitializeService) => () =>
        appInitialize.initialize(),
      deps: [AppInitializeService],
      multi: true,
    },
    MessageService,
  ],
};
