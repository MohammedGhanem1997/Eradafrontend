import { Component } from '@angular/core';

@Component({
  selector: 'app-suppliers',
  standalone: true,
  imports: [],
  templateUrl: './suppliers.component.html',
  styleUrl: './suppliers.component.scss'
})
export class SuppliersComponent {

}
