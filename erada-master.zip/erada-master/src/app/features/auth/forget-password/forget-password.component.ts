import { NgClass, NgStyle } from '@angular/common';
import { Component, signal } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { LocalizeRouterModule } from '@gilsdav/ngx-translate-router';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { ButtonComponent } from '@shared/_components/button/button.component';
import { DialogService } from 'primeng/dynamicdialog';
import { InputOtpModule } from 'primeng/inputotp';

@Component({
  selector: 'app-forget-password',
  standalone: true,
  imports: [
    TranslateModule,
    RouterModule,
    LocalizeRouterModule,
    InputOtpModule,
    FormsModule,
    NgStyle,
    ReactiveFormsModule,
    NgClass,
    ButtonComponent
  ],
  templateUrl: './forget-password.component.html',
  styleUrl: './forget-password.component.scss',
  providers: [DialogService]
})
export class ForgetPasswordComponent {

  activeIndex = signal(0)
  currentLang = signal('')
  showPassword = signal(false)
  showConfirmPassword = signal(false)
  passwordStrength = signal(0)
  strengthText = signal('')
  steps = [
    { label: '1' },
    { label: '2' },
    { label: '3' },
  ];
  passwordForm!: FormGroup
  staffId = new FormControl('', [Validators.required, Validators.minLength(6)])
  otp = new FormControl('', [Validators.required, Validators.minLength(6)])
  
  constructor(
    public dialogService: DialogService,
    public translateService: TranslateService,
    private fb: FormBuilder
  ) {
    this.currentLang.set(this.translateService.currentLang)
    this.createPasswordForm()
    this.passwordForm.get('password')?.valueChanges.subscribe(value => {
      this.updatePasswordStrength(value);
    })
  }


  createPasswordForm() {
    this.passwordForm = this.fb.group({
      password: ['', Validators.required],
      confirmPassword: ['', Validators.required]
    }, { validators: this.passwordsMatchValidator })
  }

  passwordsMatchValidator(control: AbstractControl): { [key: string]: boolean } | null {
    const password = control.get('password');
    const confirmPassword = control.get('confirmPassword');
    if (password && confirmPassword && password.value !== confirmPassword.value) {
      return { 'passwordMismatch': true };
    }
    return null;
  }

  
  updatePasswordStrength(password: string) {
    let strength = 0;
    if (password.length >= 8) strength += 1;
    if (/[a-z]/.test(password)) strength += 1;
    if (/[A-Z]/.test(password)) strength += 1;
    if (/[0-9]/.test(password)) strength += 1;
    if (/[\W_]/.test(password)) strength += 1;
    if (strength <= 2) {
      this.passwordStrength.set(33)
      this.currentLang() == 'ar' ? this.strengthText.set('ضعيف')  : this.strengthText.set('Weak')
    } else if (strength === 3 || strength === 4) {
      this.passwordStrength.set(66)
      this.currentLang() == 'ar' ? this.strengthText.set('جيد') : this.strengthText.set('Good')
    } else if (strength === 5) {
      this.passwordStrength.set(100)
      this.currentLang() == 'ar' ? this.strengthText.set('قوي') : this.strengthText.set('Strong')
    }
  }

  toggleShowPassword() {
    this.showPassword.update((v) => v = !v )
  }

  toggleShowConfirmPassword() {
    this.showConfirmPassword.update((v) => v = !v )
  }

  nextStaff(event: any) {
    if(this.staffId.invalid) {
      this.staffId.markAsTouched()
      return
    }
    this.activeIndex.set(this.activeIndex()+1);
  }
  nextOTP(event: any) {
    if(this.otp.invalid) {
      this.otp.markAsTouched()
      return
    }
    this.activeIndex.set(this.activeIndex()+1);
  }

  prev() {
    this.activeIndex.set(this.activeIndex()-1);
  }

  submit(event: any) {
    if(this.passwordForm.invalid) {
      this.passwordForm.markAllAsTouched()
      return
    }
    import('../../../@shared/_components/dynamic-popup/dynamic-popup.component').then(c => {
      this.dialogService.open(c.DynamicPopupComponent, {
        showHeader: true,
        width: '25vw',
        modal: true,
        styleClass: 'er_p-dialog',
        data: {
          title: 'screens.dynamic_popup.password_changed.password_changed', 
          subTitle: 'screens.dynamic_popup.password_changed.password_changed_info', 
          icon: 'icon_success.svg',
          buttonText: 'screens.dynamic_popup.password_changed.password_changed_btn',
          routeUrl: 'login'
        }
      })
    })
  }

}
