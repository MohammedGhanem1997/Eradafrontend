import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import { LocalizeRouterModule } from '@gilsdav/ngx-translate-router';
import { TranslateModule } from '@ngx-translate/core';
import { InputDropdownComponent } from '@shared/_components';
import { AccordionModule } from 'primeng/accordion';

@Component({
  selector: 'app-need-help',
  standalone: true,
  imports: [
    TranslateModule,
    InputDropdownComponent,
    AccordionModule,
    RouterModule,
    LocalizeRouterModule
  ],
  templateUrl: './need-help.component.html',
  styleUrl: './need-help.component.scss'
})
export class NeedHelpComponent {

  questionsList: {name: string, code: string}[] = [
    { name: 'ماهي اراده', code: '' },
    { name: 'كيف تنضم الينا', code: '' },
    { name: 'شروط القروض', code: '' }
  ]

  accodionList: any[] = [
    {
      question: 'كيف يمكن لأداة إدارة اتصالات أن تساعدني في إدارة عملي؟',
      answer: 'لوريم إيبسوم هو ببساطة نص وهمي من صناعة الطباعة والتنضيد. لقد أصبح النص الوهمي القياسي في الصناعة منذ ذلك الحين. لوريم إيبسوم هو ببساطة نص وهمي من صناعة الطباعة والتنضيد. لقد أصبح النص الوهمي القياسي في الصناعة منذ ذلك الحين.',
      isOpen: false
    },
    {
      question: 'كيف يمكنني التقديم علي قرض؟',
      answer: 'لوريم إيبسوم هو ببساطة نص وهمي من صناعة الطباعة والتنضيد. لقد أصبح النص الوهمي القياسي في الصناعة منذ ذلك الحين. لوريم إيبسوم هو ببساطة نص وهمي من صناعة الطباعة والتنضيد. لقد أصبح النص الوهمي القياسي في الصناعة منذ ذلك الحين.',
      isOpen: false
    },
    {
      question: 'ما هي اداره وكيف يمكنني الانضمام؟',
      answer: 'لوريم إيبسوم هو ببساطة نص وهمي من صناعة الطباعة والتنضيد. لقد أصبح النص الوهمي القياسي في الصناعة منذ ذلك الحين. لوريم إيبسوم هو ببساطة نص وهمي من صناعة الطباعة والتنضيد. لقد أصبح النص الوهمي القياسي في الصناعة منذ ذلك الحين.',
      isOpen: false
    },
    {
      question: 'كيف يمكن لأداة إدارة اتصالات أن تساعدني في إدارة عملي؟',
      answer: 'لوريم إيبسوم هو ببساطة نص وهمي من صناعة الطباعة والتنضيد. لقد أصبح النص الوهمي القياسي في الصناعة منذ ذلك الحين. لوريم إيبسوم هو ببساطة نص وهمي من صناعة الطباعة والتنضيد. لقد أصبح النص الوهمي القياسي في الصناعة منذ ذلك الحين.',
      isOpen: false
    },
    {
      question: 'كيف يمكن لأداة إدارة اتصالات أن تساعدني في إدارة عملي؟',
      answer: 'لوريم إيبسوم هو ببساطة نص وهمي من صناعة الطباعة والتنضيد. لقد أصبح النص الوهمي القياسي في الصناعة منذ ذلك الحين. لوريم إيبسوم هو ببساطة نص وهمي من صناعة الطباعة والتنضيد. لقد أصبح النص الوهمي القياسي في الصناعة منذ ذلك الحين.',
      isOpen: false
    },
  ]

  onTabOpen(event: any) {
    this.accodionList[event.index].isOpen = true;
  }

  onTabClose(event: any) {
    this.accodionList[event.index].isOpen = false;
  }

}
