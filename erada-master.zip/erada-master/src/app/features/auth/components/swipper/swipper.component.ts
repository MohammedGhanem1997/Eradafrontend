import { isPlatformBrowser } from '@angular/common';
import { Component, CUSTOM_ELEMENTS_SCHEMA, ElementRef, Inject, NgZone, PLATFORM_ID, signal, ViewChild } from '@angular/core';
import { SwiperOptions } from 'swiper/types';
import { Autoplay, Pagination } from 'swiper/modules';
import { SwipperService } from '@core/@services/swipper/swipper.service';
import { SwiperContainer } from 'swiper/element';
import { TranslateModule } from '@ngx-translate/core';


@Component({
  selector: 'app-swipper',
  standalone: true,
  imports: [
    TranslateModule,
  ],
  templateUrl: './swipper.component.html',
  styleUrl: './swipper.component.scss',
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class SwipperComponent {

  @ViewChild('swiper', { static: true }) swiper!: ElementRef<SwiperContainer>
  index = 0
  currentYear = signal(new Date().getFullYear())

  constructor(
    private ngZone: NgZone,
    @Inject(PLATFORM_ID) private platformId: string,
    swiperService: SwipperService
  ) { }

  swiperConfig: SwiperOptions = {
    modules: [Pagination, Autoplay],
    // injectStylesUrls: ['swiper.css'],
    spaceBetween: 10,
    pagination: {
      el: '.custom-pagination',
      clickable: true,
      renderBullet: (index, className) => {
        return `<span class="w-2 h-2 bg-[#A4A8AC] rounded-full cursor-pointer z-30" (click)="slideChange()" ></span>`;
      },
    },
    autoplay: {
      delay: 5000,
    },
  }

  ngOnInit(): void {
    this.ngZone.runOutsideAngular(() => this.initSwiper())
  }

  initSwiper() {
    const swiperElement = this.swiper?.nativeElement
    Object.assign(swiperElement, {
      ...this.swiperConfig,
    });
    if (isPlatformBrowser(this.platformId)) swiperElement?.initialize()
  }

  ngAfterViewInit(): void {
    if (isPlatformBrowser(this.platformId))
      this.swiper.nativeElement.swiper.update()
      this.swiper.nativeElement.swiper.activeIndex = this.index;
  }

  slideChange(swiper: any) {
    this.index = swiper.detail[0].activeIndex;
    console.log(this.index);
    
  }

}
