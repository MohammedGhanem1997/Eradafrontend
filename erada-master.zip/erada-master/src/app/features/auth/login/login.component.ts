import { Component, signal } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { LocalizeRouterModule } from '@gilsdav/ngx-translate-router';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { DialogService } from 'primeng/dynamicdialog';
import { SwipperComponent } from '../components/swipper/swipper.component';
import { DynamicPopupComponent, InputTextComponent } from '@shared/_components';
import { ButtonComponent } from '@shared/_components/button/button.component';
import { Langs } from '@core/@models';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [
    TranslateModule,
    FormsModule,
    RouterModule,
    LocalizeRouterModule,
    ReactiveFormsModule,
    DynamicPopupComponent,
    SwipperComponent,
    InputTextComponent,
    ButtonComponent,
  ],
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss',
  providers: [DialogService]
})
export class LoginComponent {

  currentYear = signal(new Date().getFullYear())
  selectedLang = signal<{label: string, lang: string, fontFamily: string } | null>(null)
  langs = [
    { label: 'English', lang: 'en', fontFamily: 'Montserrat' },
    { label: 'العربية', lang: 'ar', fontFamily: 'Noto' }
  ]
  loginForm!: FormGroup
  
  constructor(
    private translateService: TranslateService,
    private router: Router,
    private fb: FormBuilder,
    public dialogService: DialogService
  ) {
    this.createLoginForm()
    this.selectedLang.set(this.translateService.currentLang == 'en' ? this.langs[0] : this.langs[1])
  }
  
  
  switchLang() {
    const lang = this.selectedLang()?.lang == 'en' ? Langs.Arabic : Langs.English
    window.location.replace(`${lang}/${this.router.url.slice(4)}`)
  }

  createLoginForm() {
    this.loginForm = this.fb.group({
      staffId: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(3) ]]
    })
  }

  get staffIdControl() {
    return this.loginForm.controls['staffId'] as FormControl<string>
  }

  get passwordControl() {
    return this.loginForm.controls['password'] as FormControl<string>
  }

  submit(event: any) {
    if(this.loginForm.invalid) {
      this.loginForm.markAllAsTouched()
      return
    }
    // import('../dynamic-popup/dynamic-popup.component').then(c => {
    //   this.dialogService.open(c.DynamicPopupComponent, {
    //     showHeader: true,
    //     width: '25vw',
    //     modal: true,
    //     styleClass: 'er_p-dialog',
    //     data: {
    //       title: 'screens.dynamic_popup.password_expired.password_expired', 
    //       subTitle: 'screens.dynamic_popup.password_expired.password_expired_info', 
    //       icon: 'icon-error.svg',
    //       buttonText: 'screens.dynamic_popup.password_expired.password_expired_btn',
    //     }
    //   })
    // })
    this.router.navigate([''])
  }

  
}
