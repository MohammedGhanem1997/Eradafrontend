import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BranchSearchContainerComponent } from './branch-search-container.component';

describe('BranchSearchContainerComponent', () => {
  let component: BranchSearchContainerComponent;
  let fixture: ComponentFixture<BranchSearchContainerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [BranchSearchContainerComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(BranchSearchContainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
