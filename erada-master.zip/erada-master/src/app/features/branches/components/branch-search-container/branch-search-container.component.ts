import {
  Component,
  computed,
  Input,
  OnDestroy,
  OnInit,
  signal,
} from '@angular/core';
import { SearchInputComponent } from '@shared/_components/search-input/search-input.component';
import {
  EradaFilter,
  FilterValues,
  SearchCriteriaInterface,
} from '@core/@models';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { DropdownModule } from 'primeng/dropdown';
import { ReactiveFormsModule } from '@angular/forms';
import { RadioButtonModule } from 'primeng/radiobutton';
import { ButtonComponent } from '@shared/_components/button/button.component';
import { TableComponent } from '@shared/_components/table/table.component';
import { FilterComponent } from '@shared/_components/filter/filter.component';
import { BranchesApiService } from '@features/branches/services';
import {
  AllBranches,
  AllBranchesPayload,
  BranchStatus,
} from '@features/branches/models';
import { GovernatesService } from '@core/@services/governates/governates.service';
import {
  BehaviorSubject,
  combineLatest,
  debounceTime,
  distinctUntilChanged,
  finalize,
  map,
  Subject,
  switchMap,
  takeUntil,
} from 'rxjs';
import { FilterDataList, GroupCols } from '@features/branches/data';
import { AsyncPipe } from '@angular/common';
import { MenuItem, MenuItemCommandEvent } from 'primeng/api';
import { DialogService } from 'primeng/dynamicdialog';

@Component({
  selector: 'app-branch-search-container',
  standalone: true,
  imports: [
    SearchInputComponent,
    TranslateModule,
    DropdownModule,
    ReactiveFormsModule,
    RadioButtonModule,
    ButtonComponent,
    TableComponent,
    FilterComponent,
    AsyncPipe,
  ],
  templateUrl: './branch-search-container.component.html',
  styleUrl: './branch-search-container.component.scss',
  providers: [DialogService],
})
export class BranchSearchContainerComponent implements OnInit, OnDestroy {
  constructor(
    private branchsApiService: BranchesApiService,
    private governatesService: GovernatesService,
    private translateService: TranslateService,
    public dialogService: DialogService,
    private translate: TranslateService
  ) {}

  get groupCols() {
    return GroupCols;
  }

  private filterDataListSubject = new BehaviorSubject<EradaFilter[]>(
    FilterDataList
  );
  filterDataList$ = this.filterDataListSubject.asObservable();
  filterDataList: EradaFilter[] = [];

  @Input() set branchStatus(status: BranchStatus) {
    this.branchStatusSubject.next(status);
    this.moreDetailsOptions = this.getMoreDetailsOptions(status);
  }
  branchList = signal<AllBranches[]>([]);
  totalRecord = signal<number>(0);
  itemsPerPage = signal<number>(0);

  private searchSubject = new BehaviorSubject<SearchCriteriaInterface | null>(
    null
  );
  private filterSubject = new BehaviorSubject<FilterValues[]>([]);
  private branchStatusSubject = new BehaviorSubject<any>(BranchStatus.Active);
  private paginatorSubject = new BehaviorSubject<AllBranchesPayload>({
    limit: 5,
    page: 1,
  });
  destroy$ = new Subject<void>();
  loading$ = new BehaviorSubject<boolean>(false);

  searchFilterOptions = [
    { label: 'بحث في الكل', id: '' },
    // { label: 'الرقم التعريفي', id: 'id' },
    { label: 'اسم الفرع', id: 'name' },
  ];

  moreDetailsOptions: MenuItem[] = [];

  branchesPayload: AllBranchesPayload = {
    limit: 10,
    page: 1,
  };

  ngOnInit(): void {
    this.setupDataFetching();
    this.getAllGovernates();
    this.filterDataList$.subscribe((data) => {
      this.filterDataList = data; // Assign the latest filter data to the component property
    });
  }

  getMoreDetailsOptions(status: BranchStatus): MenuItem[] {
    const options: MenuItem[] = [
      {
        label: 'screens.branches.show_branch',
        icon: 'icon-book.svg',
        routerLink: '/branches/branch-details',
      },
      {
        label: 'screens.branches.edit_branch',
        icon: 'icon-edit.svg',
        command: (event: any) => this.handleMenuClick(event.id),
      },
    ];

    if (status === BranchStatus.Active) {
      options.push({
        label: 'screens.branches.freeze_branch',
        icon: 'icon-timer.svg',
        command: (event: any) =>
          this.onChangeStatus(event.id, BranchStatus.Freeze),
      });
    }

    if (status === BranchStatus.Closed || status === BranchStatus.Freeze) {
      options.push({
        label: 'screens.branches.activate_branch',
        icon: 'icon-active-branch.svg',
        command: (event: any) =>
          this.onChangeStatus(event.id, BranchStatus.Active),
      });
    }
    if (status === BranchStatus.Active || status === BranchStatus.Freeze) {
      options.push({
        label: 'screens.branches.close_branch',
        icon: 'icon-close-branch.svg',
        command: (event: any) =>
          this.onChangeStatus(event.id, BranchStatus.Closed),
      });
    }
    console.log(options);
    return options;
  }
  setupDataFetching(): void {
    combineLatest([
      this.searchSubject,
      this.filterSubject,
      this.branchStatusSubject,
      this.paginatorSubject,
    ])
      .pipe(
        debounceTime(300),
        distinctUntilChanged(
          (prev, curr) => JSON.stringify(prev) === JSON.stringify(curr)
        ),
        switchMap(([search, filters, status, paginator]) => {
          this.loading$.next(true);
          const payload: AllBranchesPayload = {
            limit: paginator.limit,
            page: paginator.page,
            status: status,
            ...(search && { [search.option]: search.term }),
            ...filters.reduce(
              (acc, filter) => ({ ...acc, [filter.field]: filter.value }),
              {}
            ),
          };
          return this.branchsApiService.getAllBranches(payload).pipe(
            map((res) => ({
              ...res,
              data: {
                ...res.data,
                items: res.data.items.map((item) => ({
                  ...item,
                  icon: 'icon-manage.svg',
                })),
              },
            })),
            finalize(() => {
              this.loading$.next(false);
            })
          );
        }),
        takeUntil(this.destroy$)
      )
      .subscribe({
        next: (res) => {
          this.branchList.set(res.data.items);
          this.itemsPerPage.set(res.data.meta.itemsPerPage);
          this.totalRecord.set(res.data.meta.totalItems);
        },
      });
  }

  getPaginator(event: AllBranchesPayload) {
    const { limit, page } = event;
    this.paginatorSubject.next({ limit, page });
  }

  getAllGovernates() {
    this.governatesService.getData().subscribe({
      next: (res) => {
        const filterData = this.filterDataListSubject
          .getValue()
          .map((filter) => {
            if (filter.control === 'governate') {
              return {
                ...filter,
                data: res,
                optionLabel:
                  this.translateService.currentLang === 'ar'
                    ? 'governorate.ar'
                    : 'governorate.en',
              };
            }
            if (filter.control === 'area') {
              return {
                ...filter,
                optionLabel:
                  this.translateService.currentLang === 'ar'
                    ? 'name.ar'
                    : 'name.en',
              };
            }
            return filter;
          });

        this.filterDataListSubject.next(filterData);
      },
    });
  }
  onSearch(event: SearchCriteriaInterface) {
    this.searchSubject.next(event);
  }

  onFilter(filterData: FilterValues[]) {
    this.filterSubject.next(filterData);
  }

  handleMenuClick(id: string) {
    import('../create-branch/create-branch.component').then((c) => {
      const ref = this.dialogService.open(c.CreateBranchComponent, {
        styleClass: 'er_p-dialog er_background-p-dialog',
        header: this.translate.instant('shared.buttons.edit_new_branch'),
        rtl: true,
        width: '100%',
        height: '100%',
        data: {
          id: id,
        },
      });
      if (ref && ref.onClose) {
        ref.onClose.subscribe((_) => {
          this.setupDataFetching();
        });
      }
    });
  }

  onChangeStatus(id: string, status: BranchStatus) {
    const popupConfig: Record<
      BranchStatus,
      { title: string; subTitle?: string; icon: string; buttonText: string }
    > = {
      [BranchStatus.Freeze]: {
        title: 'screens.dynamic_popup.branches.confirm_freeze_branch',
        subTitle: 'screens.dynamic_popup.branches.freeze_branch_message',
        icon: 'icon-attention.svg',
        buttonText: 'shared.buttons.stop',
      },
      [BranchStatus.Closed]: {
        title: 'screens.dynamic_popup.branches.confirm_close_branch',
        subTitle: 'screens.dynamic_popup.branches.close_branch_message',
        icon: 'icon-attention.svg',
        buttonText: 'shared.buttons.close',
      },
      [BranchStatus.Active]: {
        title: 'screens.dynamic_popup.branches.confirm_active_branch',
        icon: 'icon-attention-grey.svg',
        buttonText: 'shared.buttons.activate',
      },
    };

    const data = popupConfig[status];

    import('@shared/_components/dynamic-popup/dynamic-popup.component').then(
      (c) => {
        const ref = this.dialogService.open(c.DynamicPopupComponent, {
          showHeader: true,
          width: '25vw',
          modal: true,
          styleClass: 'er_p-dialog',
          data: data,
        });
        if (ref && ref.onClose) {
          ref.onClose.subscribe((_) => {
            this.updateBranchStatus(id, status);
          });
        }
      }
    );
  }

  updateBranchStatus(id: string, status: string) {
    this.branchsApiService.changeBranchStatus(id, status).subscribe({
      next: (res) => {
        this.setupDataFetching();
      },
    });
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
