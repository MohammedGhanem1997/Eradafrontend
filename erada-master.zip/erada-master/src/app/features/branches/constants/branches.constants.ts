import { environment } from 'src/environments/environment';

export const BranchesEndpoints = {
  GET_BRANCHES: environment.preDevURL + '/branch/all',
  CREATE_BRANCH: environment.preDevURL + '/branch',
  GET_SPECIFIC_BRANCH: environment.preDevURL + '/branch',
  UPDATE_BRANCH_STATUS: environment.preDevURL + '/branch',
  GET_BRANCHES_STATUS: environment.preDevURL + '/branch/status',
} as const;
