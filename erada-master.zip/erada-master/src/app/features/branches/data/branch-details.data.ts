import { ColType, EradaColumn } from "@core/@models";
import { MenuItem } from "primeng/api";

  export const ProductTableCols: EradaColumn[] = [
    { field: 'staffId', header: 'الرقم التعريفي' },
    { field: 'productName', header: ' اسم المنتج' },
    { field: 'productType', header: 'نوع المنتج' },
    { field: 'loanNumber', header: 'عدد القروض' },
    { field: 'loanAmount', header: 'قيمة القروض' },
    { field: 'productStatus', header: 'حالة المنتج', type: ColType.Status },
    { field: 'icon', header: '' },
  ];

  export const EmployeeTableCols: EradaColumn[] = [
    { field: 'staffId', header: 'الرقم التعريفي' },
    { field: 'employeeName', header: 'اسم الموظف' },
    { field: 'groupName', header: 'المجموعه' },
    { field: 'roleName', header: 'الدور' },
    { field: 'mobile', header: 'رقم الموبايل' },
    { field: 'loanNumber', header: 'عدد القروض' },
    { field: 'icon', header: '' },
  ];

  export const MoreDetailsProduct: MenuItem[] = [
    {
      label: 'عرض المنتج',
      icon: 'icon-book.svg',
      routerLink: 'product-details',
    },
    { label: 'فك الربط', icon: 'icon-unlink.svg' },
  ];

  export const MoreDetailsEmployee: MenuItem[] = [
    {
      label: 'عرض الموظف',
      icon: 'icon-book.svg',
      routerLink: 'employee-details',
    },
    { label: 'اضافة للمجموعه', icon: 'icn_add policy.svg' },
    { label: 'ربط بالدور', icon: 'icon-link.svg' },
    { label: 'نقل محفظة', icon: 'icon-waalet.svg' },
  ];