export interface CreateBranchPayload {
  name: string;
  managerId: string;
  area: string;
  government: string;
  lat: string;
  len: string;
  street: string;
  city: string;
  buildingNO: string;
  landmark: string;
}
