import { TestBed } from '@angular/core/testing';

import { BranchesManageStateService } from './branches-manage-state.service';

describe('BranchesManageStateService', () => {
  let service: BranchesManageStateService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BranchesManageStateService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
