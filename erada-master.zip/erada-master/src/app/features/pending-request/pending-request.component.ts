import { Component } from '@angular/core';

@Component({
  selector: 'app-pending-request',
  standalone: true,
  imports: [],
  templateUrl: './pending-request.component.html',
  styleUrl: './pending-request.component.scss'
})
export class PendingRequestComponent {

}
