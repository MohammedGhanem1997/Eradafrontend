import { Component, input, signal } from '@angular/core';
import { InputTextComponent } from '../../../../@shared/_components/input-text/input-text.component';
import { InputDropdownComponent } from '../../../../@shared/_components/input-dropdown/input-dropdown.component';
import { TranslateModule } from '@ngx-translate/core';
import { CreatePolicyForm, CreatePolicyItem } from '@core/@models';
import {
  AbstractControl,
  FormArray,
  FormBuilder,
  FormControl,
  FormGroup,
  ReactiveFormsModule,
} from '@angular/forms';
import { AppDatepickerComponent } from '../../../../@shared/_components/app-datepicker/app-datepicker.component';
import { NgFor } from '@angular/common';
import { ButtonComponent } from '../../../../@shared/_components/button/button.component';
import { InputNumberComponent } from '../../../../@shared/_components/input-number/input-number.component';
import { DynamicDialogConfig } from 'primeng/dynamicdialog';

@Component({
  selector: 'app-create-policy',
  standalone: true,
  imports: [
    InputTextComponent,
    InputDropdownComponent,
    TranslateModule,
    ReactiveFormsModule,
    AppDatepickerComponent,
    NgFor,
    ButtonComponent,
    InputNumberComponent,
  ],
  templateUrl: './create-policy.component.html',
  styleUrl: './create-policy.component.scss',
})
export class CreatePolicyComponent {
  policyId = signal<number | null>(null);

  policyForm!: CreatePolicyForm;
  constructor(private fb: FormBuilder, private dialog: DynamicDialogConfig) {}

  ngOnInit(): void {
    this.initializeForm();
    this.policyId.set(this.dialog.data?.id);
    if (this.policyId()) {
      this.loadPolicyData(this.policyId());
    }
  }

  get items(): FormArray<CreatePolicyItem> {
    return this.policyForm.get('items') as FormArray<CreatePolicyItem>;
  }

  loadPolicyData(policyId: number | null): void {
    this.patchFormForEdit([
      {
        policyName: 'test',
        purchaseAmount: 1200,
        saleAmount: 2000,
        startDate: '2024-10-08T21:00:00.000Z',
        endDate: '2024-10-29T21:00:00.000Z',
      },
      {
        policyName: 'test2',
        purchaseAmount: 1300,
        saleAmount: 3000,
        startDate: '2024-10-21T21:00:00.000Z',
        endDate: '2024-11-07T22:00:00.000Z',
      },
    ]);
  }
  private patchFormForEdit(policyData: Array<any>) {
    if (policyData) {
      // this.policyForm.patchValue({
      //   items: policyData,
      // });

      this.items.clear();
      policyData.forEach((item) => {
        this.items.push(this.createPolicyFormGroup(item));
      });
    }
  }

  private createPolicyFormGroup(policy?: any): CreatePolicyItem {
    return this.fb.group(
      {
        policyName: new FormControl<string>({
          value: policy?.policyName || '',
          disabled: !!this.policyId(),
        }),
        purchaseAmount: new FormControl<number | null>({
          value: policy?.purchaseAmount || null,
          disabled: !!this.policyId(),
        }),
        saleAmount: new FormControl<number | null>({
          value: policy?.saleAmount || null,
          disabled: !!this.policyId(),
        }),
        startDate: new FormControl<Date | null>({
          value: policy?.startDate ? new Date(policy?.startDate) : null,
          disabled: !!this.policyId(),
        }),
        endDate: new FormControl<Date | null>(
          policy?.endDate ? new Date(policy?.endDate) : null
        ),
      },
      { validators: this.dateValidator }
    );
  }

  dateValidator(form: AbstractControl) {
    const startDate = form.get('startDate')?.value;
    const endDate = form.get('endDate')?.value;

    if (startDate && endDate && startDate > endDate) {
      return { dateInvalid: true }; // Validation fails if startDate is greater than endDate
    }
    return null; // Return null if validation passes
  }
  private initializeForm(): void {
    this.policyForm = this.fb.group({
      items: this.fb.array([this.createPolicyFormGroup()]),
    }) as CreatePolicyForm;
  }
  addItem(): void {
    if (this.policyForm.valid) {
      this.items.push(this.createPolicyFormGroup());
    }
  }
  getControl(controlName: string, item: FormGroup): FormControl {
    const control = item.get(controlName);
    return control as FormControl;
  }

  onCreate() {
    if (this.policyForm.valid) {
      console.log(this.policyForm.value);
    } else {
      console.log('error validation');
    }
  }
}
