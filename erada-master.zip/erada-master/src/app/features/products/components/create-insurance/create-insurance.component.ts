import { Component, signal } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { CreateInsuranceForm } from '@core/@models';
import { TranslateModule } from '@ngx-translate/core';
import { ButtonComponent, InputDropdownComponent, InputTextComponent } from '@shared/_components';
import { DynamicDialogConfig } from 'primeng/dynamicdialog';

@Component({
  selector: 'app-create-insurance',
  standalone: true,
  imports: [
    TranslateModule,
    InputTextComponent,
    ButtonComponent,
    InputDropdownComponent,
    ReactiveFormsModule
  ],
  templateUrl: './create-insurance.component.html',
  styleUrl: './create-insurance.component.scss'
})
export class CreateInsuranceComponent {

  insuranceForm!: CreateInsuranceForm
  insuranceId = signal<string>('')

  constructor(
    private fb: FormBuilder,
    private dialog: DynamicDialogConfig
  ) {
    this.createInsuranceForm()
    this.insuranceId.set(this.dialog.data.id)
  }

  createInsuranceForm() {
    this.insuranceForm = this.fb.group({
      compnayName: [''],
      bankName: [''],
      companyAccountNo: [''],
      eradaAccountNo: ['']
    })
  }

  bankList: {name: string, code: string}[] = [
    { name: 'الاهلي', code: '' },
    { name: 'كريدي اجريكول', code: '' },
    { name: 'مصر', code: '' }
  ]

  getEvent(event: any) {

  }

}

