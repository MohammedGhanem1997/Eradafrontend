import { Component } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { SectionInterface, Status } from '@core/@models';
import {
  LocalizeRouterModule,
  LocalizeRouterService,
} from '@gilsdav/ngx-translate-router';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import {
  CardDetailsComponent,
  HomeCardStatisticsComponent,
  StatusStatisticsComponent,
} from '@shared/_components';
import { MenuItem } from 'primeng/api';
import { HeaderComponent } from 'src/app/@block';
import { DialogService, DynamicDialogModule } from 'primeng/dynamicdialog';
import { TabViewModule } from 'primeng/tabview';
import { ProductsSearchContainerComponent } from './components/products-search-container/products-search-container.component';

@Component({
  selector: 'app-products',
  standalone: true,
  imports: [
    HeaderComponent,
    TranslateModule,
    HomeCardStatisticsComponent,
    StatusStatisticsComponent,
    CardDetailsComponent,
    LocalizeRouterModule,
    RouterModule,
    DynamicDialogModule,
    TabViewModule,
    ProductsSearchContainerComponent,
  ],
  templateUrl: './products.component.html',
  styleUrl: './products.component.scss',
  providers: [DialogService],
})
export class ProductsComponent {
  constructor(
    public dialogService: DialogService,
    private translate: TranslateService,
    private localizeRouterService: LocalizeRouterService,
    private router: Router
  ) {}

  insuranceCompaniesLength = [1, 2, 3];

  getEvent(event: any) {
    this.createProduct();
  }

  insuranceSections: SectionInterface[] = [
    { label: 'حالة الشركة', value: 'نشط', type: 'status' },
    { label: 'عدد الوثائق', value: '8' },
    { label: 'تاريخ الانشاء', value: '16/5/2024' },
  ];

  insuranceItems: MenuItem[] = [
    {
      label: 'عرض الشركة',
      icon: 'icon-book.svg',
      command: () => this.showDetails(1),
    },
    {
      label: 'إضافة وثيقة',
      icon: 'add-circle.svg',
      command: () => this.createInsurancePolicy(),
    },
    {
      label: 'تعديل',
      icon: 'icon-edit.svg',
      command: () => this.editInsuranceCompany(),
    },
    { label: 'أرشفة الشركة', icon: 'icon-archived-company.svg' },
  ];

  statusList = { نشط: Status.Success, 'غير نشط': Status.Error };

  showDetails(companyId: number) {
    const translatedRoute = this.localizeRouterService.translateRoute([
      '/products/insurance-details/',
      companyId,
    ]) as any;
    this.router.navigate(translatedRoute);
  }

  createInsuranceCompany() {
    import('./components/create-insurance/create-insurance.component').then(
      (c) =>
        this.dialogService.open(c.CreateInsuranceComponent, {
          styleClass: 'er_p-dialog er_background-p-dialog',
          header: this.translate.instant(
            'screens.products.create_insurance_company'
          ),
          rtl: true,
          width: '100%',
          height: '100%',
          data: {
            id: '0',
          },
        })
    );
  }

  editInsuranceCompany() {
    import('./components/create-insurance/create-insurance.component').then(
      (c) =>
        this.dialogService.open(c.CreateInsuranceComponent, {
          styleClass: 'er_p-dialog er_background-p-dialog',
          header: this.translate.instant(
            'screens.products.edit_insurance_company'
          ),
          rtl: true,
          width: '100%',
          height: '100%',
          data: {
            id: '10',
          },
        })
    );
  }

  createInsurancePolicy() {
    import('./components/create-policy/create-policy.component').then((c) =>
      this.dialogService.open(c.CreatePolicyComponent, {
        styleClass: 'er_p-dialog er_background-p-dialog',
        header: this.translate.instant(
          'screens.insurance_details.menu_create_policy'
        ),
        rtl: true,
        width: '100%',
        height: '100%',
      })
    );
  }
  createProduct() {
    import('./components/create-product/create-product.component').then((c) =>
      this.dialogService.open(c.CreateProductComponent, {
        styleClass: 'er_p-dialog er_background-p-dialog',
        header: this.translate.instant(
          'screens.create_product.add_new_product'
        ),
        rtl: true,
        width: '100%',
        height: '100%',
      })
    );
  }
}
