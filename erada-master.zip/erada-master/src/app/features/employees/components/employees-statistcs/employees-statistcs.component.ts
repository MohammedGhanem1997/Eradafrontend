import { Component, input } from '@angular/core';
import { EradaFilter, FilterTypeEnum } from '@core/@models';
import { TranslateModule } from '@ngx-translate/core';
import { FilterComponent } from '@shared/_components';
import { ChartData, ChartOptions, ChartType } from 'chart.js';
import { BaseChartDirective } from 'ng2-charts';
import { ChartComponent } from '../../../../@shared/_components/chart/chart.component';

@Component({
  selector: 'app-employees-statistcs',
  standalone: true,
  imports: [
    BaseChartDirective,
    TranslateModule,
    FilterComponent,
    ChartComponent,
  ],
  templateUrl: './employees-statistcs.component.html',
  styleUrl: './employees-statistcs.component.scss',
})
export class EmployeesStatistcsComponent {
  chartType = input.required<ChartType>();
  chartOptions = input<ChartOptions<ChartType>>();
  chartData = input.required<ChartData<ChartType>>();
  title = input.required<string>();
  subTitle = input.required<string>();
  customYTick = input<string>('');

  filterDataList: EradaFilter[] = [
    {
      label: 'shared.filter.date',
      control: 'date',
      type: FilterTypeEnum.date,
      data: [],
    },
    {
      label: 'screens.employees_group_details.area',
      placeholder: 'screens.employees_group_details.all_areas',
      control: 'area',
      type: FilterTypeEnum.dropdwon,
      data: [
        { name: 'السلام', value: '1' },
        { name: 'مصرالجديده', value: '2' },
        { name: 'المطريه', value: '3' },
        { name: 'سرايا القبه', value: '4' },
      ],
    },
    {
      label: 'shared.pages.branches',
      placeholder: 'screens.branches.all_branches',
      control: 'branchStatus',
      type: FilterTypeEnum.dropdwon,
      data: [
        { name: 'السلام', value: '1' },
        { name: 'مصر الجديده', value: '2' },
        { name: 'المرج', value: '3' },
      ],
    },
  ];
}
