import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeesStatistcsComponent } from './employees-statistcs.component';

describe('EmployeesStatistcsComponent', () => {
  let component: EmployeesStatistcsComponent;
  let fixture: ComponentFixture<EmployeesStatistcsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [EmployeesStatistcsComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(EmployeesStatistcsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
