import { Component, input } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'erada-fieldset',
  standalone: true,
  imports: [TranslateModule],
  templateUrl: './fieldset.component.html',
  styleUrl: './fieldset.component.scss',
})
export class FieldsetComponent {
  legend = input.required<string>();
}
