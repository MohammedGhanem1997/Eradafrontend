import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeStatusTableComponent } from './employee-status-table.component';

describe('EmployeeStatusTableComponent', () => {
  let component: EmployeeStatusTableComponent;
  let fixture: ComponentFixture<EmployeeStatusTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [EmployeeStatusTableComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(EmployeeStatusTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
