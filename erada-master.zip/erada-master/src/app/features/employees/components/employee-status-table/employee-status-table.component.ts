import { Component, signal } from '@angular/core';
import { LoanCardComponent } from '@features/branches/components/loan-card/loan-card.component';
import { TranslateModule } from '@ngx-translate/core';
import { SearchInputComponent, SortButtonComponent } from '@shared/_components';
import { PaginatorModule, PaginatorState } from 'primeng/paginator';
import { MenuItem } from 'primeng/api';
import { SortList } from '@core/@models';

@Component({
  selector: 'app-employee-status-table',
  standalone: true,
  imports: [
    TranslateModule,
    SearchInputComponent,
    LoanCardComponent,
    PaginatorModule,
    SortButtonComponent,
  ],
  templateUrl: './employee-status-table.component.html',
  styleUrl: './employee-status-table.component.scss',
})
export class EmployeeStatusTableComponent {
  filterSearchOptions: any[] = [{ name: 'الرقم التعريفي', value: 'staffId' }];

  first = signal(0);
  rows = signal(10);
  sortList: MenuItem[] = [
    { label: 'shared.sortList.asc', fragment: SortList.ASC },
    { label: 'shared.sortList.desc', fragment: SortList.DESC },
    { label: 'shared.sortList.alpha', fragment: SortList.Alpha },
    { label: 'shared.sortList.temp', fragment: SortList.Time },
  ];
  onPageChange(event: PaginatorState) {
    if (event.first) {
      this.first.set(event.first);
    }
    if (event.rows) {
      this.rows.set(event.rows);
    }
  }
  getValue(value: SortList) {
    console.log(value);
  }
}
