import { Component } from '@angular/core';
import { SectionInterface, Status } from '@core/@models';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import {
  BreadcrumbComponent,
  CardDetailsComponent,
  HomeCardStatisticsComponent,
  StatusStatisticsComponent,
} from '@shared/_components';
import { MenuItem } from 'primeng/api';
import { DialogService, DynamicDialogModule } from 'primeng/dynamicdialog';
import { ProgressBarModule } from 'primeng/progressbar';
import { TabViewModule } from 'primeng/tabview';
import { EmployeeStatusTableComponent } from '../employee-status-table/employee-status-table.component';

@Component({
  selector: 'app-employee-details',
  standalone: true,
  imports: [
    TranslateModule,
    BreadcrumbComponent,
    CardDetailsComponent,
    StatusStatisticsComponent,
    ProgressBarModule,
    DynamicDialogModule,
    HomeCardStatisticsComponent,
    TabViewModule,
    EmployeeStatusTableComponent,
  ],
  templateUrl: './employee-details.component.html',
  styleUrl: './employee-details.component.scss',
  providers: [DialogService],
})
export class EmployeeDetailsComponent {
  constructor(
    public dialogService: DialogService,
    private translate: TranslateService
  ) {}

  breadcrumbList: MenuItem[] = [
    { label: 'shared.pages.employees', routerLink: 'employees' },
    { label: 'محمد ابوالنور' },
  ];

  employeeDetailsSections: SectionInterface[] = [
    { label: 'حالة العميل', value: 'نشط', type: 'status' },
    { label: 'رقم الموبايل', value: '01118009870' },
    { label: 'اسم الفرع', value: 'فرع التجمع' },
    { label: 'اسم الدور', value: 'مسئول' },
  ];
  statusList = { 'نشط': Status.Success, 'غير نشط': Status.Error };

  employeeDetailsItems: MenuItem[] = [
    {
      label: 'عرض التفاصيل',
      icon: 'icon-view-details.svg',
      url: 'employee-profile',
      command: () => this.viewDetails(),
    },
    { label: 'تغير المجموعه', icon: 'icon-change-group.svg' },
    { label: 'تغير الدور', icon: 'icon-unlink.svg' },
    { label: 'نقل محفظة', icon: 'icon-wallet.svg' },
  ];

  viewDetails() {
    import(
      '../employee-profile-details/employee-profile-details.component'
    ).then((c) =>
      this.dialogService.open(c.EmployeeProfileDetailsComponent, {
        styleClass: 'er_p-dialog er_background-p-dialog',
        header:
          this.translate.instant('shared.buttons.details') +
          ' ' +
          'محمد ابوالنور',
        rtl: true,
        width: '100%',
        height: '100%',
      })
    );
  }
}
