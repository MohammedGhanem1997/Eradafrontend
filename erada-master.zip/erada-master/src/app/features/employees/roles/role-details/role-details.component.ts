import { Component, signal } from '@angular/core';
import { MenuItem } from 'primeng/api';
import { TranslateModule } from '@ngx-translate/core';
import { FieldsetComponent } from '../../components/fieldset/fieldset.component';
import {
  ColType,
  EradaColumn,
  EradaFilter,
  FilterTypeEnum,
  FilterValues,
  SearchCriteriaInterface,
  Status,
} from '@core/@models';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { DropdownModule } from 'primeng/dropdown';
import { RadioButtonModule } from 'primeng/radiobutton';
import {
  BreadcrumbComponent,
  CardDetailsComponent,
  SearchInputComponent,
  TableComponent,
} from '@shared/_components';
import { ButtonComponent } from '@shared/_components/button/button.component';
import { HeaderComponent } from 'src/app/@block';
import { FilterComponent } from '../../../../@shared/_components/filter/filter.component';

@Component({
  selector: 'app-role-details',
  standalone: true,
  imports: [
    HeaderComponent,
    BreadcrumbComponent,
    CardDetailsComponent,
    TranslateModule,
    FieldsetComponent,
    SearchInputComponent,
    ReactiveFormsModule,
    DropdownModule,
    RadioButtonModule,
    ButtonComponent,
    TableComponent,
    FilterComponent,
  ],
  templateUrl: './role-details.component.html',
  styleUrl: './role-details.component.scss',
})
export class RoleDetailsComponent {
  breadcrumbItems: MenuItem[] = [
    {
      label: 'screens.employees_role_details.employees',
      routerLink: 'employees',
    },
    {
      label: 'screens.employees_role_details.roles',
      routerLink: 'employees/roles',
    },
    {
      label: 'screens.employees_role_details.role_details',
    },
  ];
  role = {
    title: 'اسم الدور يكتب هنا',
    subTitle: '1783497',
    id: 1,
  };
  searchFilterOptions = [
    { label: 'الرقم التعريفي', id: 122 },
    { label: 'اسم المستخدم', id: 33 },
    { label: 'اسم الموظف', id: 44 },
  ];
  employeeStatus = [
    { name: 'نشط', id: 1, code: 'active' },
    { name: 'موقوف مؤقتا', id: 2, code: 'freeze' },
    { name: 'غير نشط', id: 3, code: 'inactive' },
  ];

  roleCols: EradaColumn[] = [
    {
      field: 'staffId',
      header: 'shared.table.table_staffid',
    },
    {
      field: 'employeeName',
      header: 'shared.table.table_employeename',
    },
    {
      field: 'groupName',
      header: 'shared.table.table_group',
    },
    {
      field: 'mobile',
      header: 'shared.table.table_mobile',
    },
    {
      field: 'employee_status',
      header: 'shared.table.table_employeestatus',
      type: ColType.Status,
    },
    { field: 'icon', header: '' },
  ];
  statusList = { نشط: Status.Success, 'غير نشط': Status.Error };

  rolesDatalist = [
    {
      staffId: '2548541',
      employeeName: 'خديجة ابوالنور',
      groupName: 'الدعم الفني',
      employee_status: 'نشط',
      roleName: 'Manager',
      mobile: '01118009870',
      loanNumber: '4',
      icon: 'icon-manage.svg',
    },
    {
      staffId: '6523124',
      employeeName: 'نور مصطفي',
      employee_status: 'غير نشط',
      groupName: 'الدعم الفني',
      roleName: 'Area Manager',
      mobile: '01118009870',
      loanNumber: '12',
      icon: 'icon-manage.svg',
    },
  ];
  roleId!: number;

  moreDetailsOptions: MenuItem[] = [
    {
      label: 'screens.employees_role_details.show_employee',
      icon: 'icon-book.svg',
      routerLink: '/employees/employee-details/1',
    },
    {
      label: 'screens.employees_role_details.change_role',
      icon: 'icon-unlink.svg',
    },
  ];
  filterDataList: EradaFilter[] = [
    {
      label: 'screens.employees_role_details.group_name',
      placeholder: 'screens.employees_role_details.all_groups',
      control: 'group',
      type: FilterTypeEnum.dropdwon,
      data: [
        { name: 'القاهره', value: '1' },
        { name: 'الجيزه', value: '2' },
        { name: 'الشرقيه', value: '3' },
        { name: 'المنوفيه', value: '4' },
      ],
    },

    {
      label: 'screens.employees_role_details.employee_status',
      control: 'branchStatus',
      type: FilterTypeEnum.radioButton,
      data: [
        { name: 'نشط', value: 'active' },
        { name: 'موقوف مؤقتا', value: 'terminate' },
        { name: 'غير نشط', value: 'inActive' },
      ],
    },
  ];
  constructor(private route: ActivatedRoute) {}

  onSearch(event: SearchCriteriaInterface) {
    console.log(event.term);
    console.log(event.option);
  }
}
