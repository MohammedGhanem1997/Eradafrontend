import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AllEmployee, AllStaffPayload } from '../models';
import { GlobalResponse, SingleGlobalResponse } from '@core/@models';
import { EmployeesEndpoints } from '../constants';

@Injectable({
  providedIn: 'root',
})
export class EmployeesApiService {
  constructor(private http: HttpClient) {}

  /**
   * Retrieves all employees based on payload.
   * @param {AllStaffPayload} data  The payload containing data to get all employees.
   * @returns {Observable<GlobalResponse<AllEmployee>>}  An observable that have all employees list.
   */
  getAllEmployees(data: AllStaffPayload): Observable<GlobalResponse<AllEmployee>> {
    const params = new HttpParams({ fromObject: data as any });
    return this.http.get<GlobalResponse<AllEmployee>>(
      EmployeesEndpoints.GET_STAFF,
      { params }
    );
  }

  /**
   * Retrieves specific employee details based on id.
   * @param {string} id  The payload containing id to get specific employee details.
   * @returns {Observable<SingleGlobalResponse<AllEmployee>>}  An observable that have specific employee details.
   */
  getEmployeeById(id: string): Observable<SingleGlobalResponse<AllEmployee>> {
    return this.http.get<SingleGlobalResponse<AllEmployee>>(
      `${EmployeesEndpoints.GET_SPECIFIC_EMPLOYEE}/${id}`
    );
  }

}
