import { Component, signal } from '@angular/core';
import { MenuItem } from 'primeng/api';
import { TranslateModule } from '@ngx-translate/core';
import {
  ColType,
  EradaColumn,
  EradaFilter,
  FilterTypeEnum,
  FilterValues,
  SearchCriteriaInterface,
  Status,
} from '@core/@models';
import { ActivatedRoute } from '@angular/router';
import { DropdownModule } from 'primeng/dropdown';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { ButtonComponent } from '@shared/_components/button/button.component';
import { RadioButtonModule } from 'primeng/radiobutton';
import {
  BreadcrumbComponent,
  CardDetailsComponent,
  StatusStatisticsComponent,
  SearchInputComponent,
  TableComponent,
  FilterComponent,
} from '@shared/_components';
import { HeaderComponent } from 'src/app/@block';
@Component({
  selector: 'app-group-details',
  standalone: true,
  imports: [
    HeaderComponent,
    BreadcrumbComponent,
    CardDetailsComponent,
    TranslateModule,
    StatusStatisticsComponent,
    SearchInputComponent,
    DropdownModule,
    ReactiveFormsModule,
    ButtonComponent,
    TableComponent,
    RadioButtonModule,
    FilterComponent,
  ],
  templateUrl: './group-details.component.html',
  styleUrl: './group-details.component.scss',
})
export class GroupDetailsComponent {
  breadcrumbItems: MenuItem[] = [
    { label: 'screens.employees_groups.employees', routerLink: 'employees' },
    { label: 'اسم المجموعة' },
  ];
  items = signal([
    {
      label: 'screens.employees_groups.menu_edit',
      icon: 'icon-edit.svg',
      command: () => console.log('test'),
    },
    {
      label: 'screens.employees_groups.menu_addemployee',
      icon: 'add-circle.svg',
      command: () => console.log('test'),
    },
    {
      label: 'screens.employees_groups.menu_delete',
      icon: 'icn_delete.svg',
      command: () => console.log('test'),
    },
  ]);
  group = {
    title: 'اسم المجموعة يكتب هنا',
    subTitle: '1783497',
    id: 1,
    sections: [
      { label: 'عدد الموظفين', value: 200 },
      { label: 'تاريخ الإنشاء', value: '22/4/2023' },
    ],
  };
  searchFilterOptions = [
    { label: 'الرقم التعريفي', id: 122 },
    { label: 'اسم المستخدم', id: 33 },
    { label: 'اسم الموظف', id: 44 },
  ];
  groupId!: number;

  groupCols: EradaColumn[] = [
    {
      field: 'staffId',
      header: 'shared.table.table_staffid',
    },
    {
      field: 'employeeName',
      header: 'shared.table.table_employeename',
    },
    {
      field: 'groupName',
      header: 'shared.table.table_group',
    },
    { field: 'roleName', header: 'shared.table.table_role' },
    {
      field: 'mobile',
      header: 'shared.table.table_mobile',
    },
    {
      field: 'loanNumber',
      header: 'shared.table.table_loanscount',
    },
    {
      field: 'employee_status',
      header: 'shared.table.table_employeestatus',
      type: ColType.Status,
    },
    { field: 'icon', header: '' },
  ];
  statusList = { نشط: Status.Success, 'غير نشط': Status.Error };
  groupsDatalist = [
    {
      staffId: '2548541',
      employeeName: 'خديجة ابوالنور',
      groupName: 'الدعم الفني',
      employee_status: 'نشط',
      status: 1,
      roleName: 'Manager',
      mobile: '01118009870',
      loanNumber: '4',
      icon: 'icon-manage.svg',
    },
    {
      staffId: '6523124',
      employeeName: 'نور مصطفي',
      employee_status: 'غير نشط',
      status: 2,
      groupName: 'الدعم الفني',
      roleName: 'Area Manager',
      mobile: '01118009870',
      loanNumber: '12',
      icon: 'icon-manage.svg',
    },
  ];
  filterDataList: EradaFilter[] = [
    {
      label: 'shared.filter.governate',
      placeholder: 'shared.filter.all_governorates',
      control: 'governate',
      type: FilterTypeEnum.dropdwon,
      data: [
        { name: 'القاهره', value: '1' },
        { name: 'الجيزه', value: '2' },
        { name: 'الشرقيه', value: '3' },
        { name: 'المنوفيه', value: '4' },
      ],
    },
    {
      label: 'shared.filter.area',
      placeholder: 'shared.filter.all_areas',
      control: 'area',
      type: FilterTypeEnum.dropdwon,
      data: [
        { name: 'السلام', value: '1' },
        { name: 'مصرالجديده', value: '2' },
        { name: 'المطريه', value: '3' },
        { name: 'سرايا القبه', value: '4' },
      ],
    },
    {
      label: 'screens.employees_group_details.breanch_status',
      control: 'branchStatus',
      type: FilterTypeEnum.radioButton,
      data: [
        { name: 'نشط', value: 'active' },
        { name: 'موقوف مؤقتا', value: 'terminate' },
        { name: 'غير نشط', value: 'inActive' },
      ],
    },
  ];
  constructor(private route: ActivatedRoute, private fb: FormBuilder) {}
  ngOnInit(): void {
    this.groupId = +this.route.snapshot.paramMap.get('id')!; // Get the 'id' from the route
  }

  onSearch(event: SearchCriteriaInterface) {
    console.log(event.term);
    console.log(event.option);
  }
}
