import { environment } from 'src/environments/environment';

export const EmployeesEndpoints = {
  GET_STAFF: environment.preDevURL + '/staff/all',
  GET_SPECIFIC_EMPLOYEE: environment.preDevURL + '/staff',
};
