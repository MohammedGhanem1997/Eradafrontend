import { Component, Input, input, output, signal } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { InputTextModule } from 'primeng/inputtext';
import { DropdownModule } from 'primeng/dropdown';
import { FormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';
import { SearchCriteriaInterface } from '@core/@models';

@Component({
  selector: 'erada-search-input',
  standalone: true,
  imports: [
    IconFieldModule,
    InputIconModule,
    InputTextModule,
    DropdownModule,
    FormsModule,
    TranslateModule,
  ],
  templateUrl: './search-input.component.html',
  styleUrl: './search-input.component.scss',
})
export class SearchInputComponent {
  options = input<any[]>([]); // Array of options to display in the dropdown
  optionLabel = input<string>('label');
  optionValue = input<string>('value');

  search = output<SearchCriteriaInterface>();
  @Input() set defaultValue(value: any) {
    this.selectedOption = value;
  }
  selectedOption: any = null;
  searchTerm: string = '';
  currentLang = signal('');
  constructor(public translateService: TranslateService) {
    this.currentLang.set(this.translateService.currentLang);
  }

  onSearch() {
    if (
      this.searchTerm.trim() !== '' ||
      (this.searchTerm.trim() !== '' && this.selectedOption)
    ) {
      this.search.emit({
        term: this.searchTerm.trim(),
        option: this.selectedOption ? this.selectedOption : 'search',
      });
    } else {
      // this.search.emit({} as SearchCriteriaInterface);
    }
  }
}
