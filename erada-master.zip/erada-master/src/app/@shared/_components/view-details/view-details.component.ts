import { NgClass } from '@angular/common';
import { Component, output, signal } from '@angular/core';
import { TranslateModule, TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'erada-view-details',
  standalone: true,
  imports: [
    TranslateModule,
    NgClass
  ],
  templateUrl: './view-details.component.html',
  styleUrl: './view-details.component.scss'
})
export class ViewDetailsComponent {

  clickAction = output<any>()
  currentLang = signal('');
  constructor(public translateService: TranslateService) {
    this.currentLang.set(this.translateService.currentLang);
  }


}
