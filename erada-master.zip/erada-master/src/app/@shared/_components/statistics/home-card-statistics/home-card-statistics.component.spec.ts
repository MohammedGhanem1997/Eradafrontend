import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HomeCardStatisticsComponent } from './home-card-statistics.component';

describe('HomeCardStatisticsComponent', () => {
  let component: HomeCardStatisticsComponent;
  let fixture: ComponentFixture<HomeCardStatisticsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HomeCardStatisticsComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(HomeCardStatisticsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
