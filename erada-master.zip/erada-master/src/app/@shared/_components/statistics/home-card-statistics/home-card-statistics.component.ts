import { Component, input } from '@angular/core';
import { RouterModule } from '@angular/router';
import { LocalizeRouterModule } from '@gilsdav/ngx-translate-router';
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'erada-home-card-statistics',
  standalone: true,
  imports: [LocalizeRouterModule, RouterModule, TranslateModule],
  templateUrl: './home-card-statistics.component.html',
  styleUrl: './home-card-statistics.component.scss',
})
export class HomeCardStatisticsComponent {
  title = input('');
  subTitle = input<string | number>('');
  descriptionPercentage = input('');
  descriptionText = input('');
  color = input('');
  arrowUp = input(true);
  imageCard = input('');
  haveBackground = input(false);
  icon = input('');
  routeUrl = input('');
}
