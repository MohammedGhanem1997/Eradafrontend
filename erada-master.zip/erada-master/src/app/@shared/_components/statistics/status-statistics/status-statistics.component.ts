import { NgClass } from '@angular/common';
import { Component, input } from '@angular/core';

@Component({
  selector: 'erada-status-statistics',
  standalone: true,
  imports: [NgClass],
  templateUrl: './status-statistics.component.html',
  styleUrl: './status-statistics.component.scss',
})
export class StatusStatisticsComponent {
  title = input<string | number>('');
  subTitle = input('');
  descriptionPercentage = input('');
  descriptionText = input('');
  color = input('');
  arrowUp = input(true);
  imageCard = input('');
  haveBackground = input(false);
  haveInfo = input(false);
  icon = input('');
  customClass = input('');
  hideArrow = input(false);
  hideInfoIcon = input(false);
  subTitleClasses = input('');
}
