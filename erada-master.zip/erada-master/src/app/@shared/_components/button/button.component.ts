import { NgClass } from '@angular/common';
import { Component, input, output } from '@angular/core';
import { RouterModule } from '@angular/router';
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'erada-button',
  standalone: true,
  imports: [TranslateModule, RouterModule, NgClass],
  templateUrl: './button.component.html',
  styleUrl: './button.component.scss',
})
export class ButtonComponent {
  buttonText = input.required<string>();
  icon = input<string>('');
  customClass = input<string>();
  outputAction = output<any>();
  type = input<string>('button');
  disabled = input<boolean>(false);

  submit() {
    this.outputAction.emit('');
  }
}
