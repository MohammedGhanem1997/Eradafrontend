import {
  Component,
  computed,
  input,
  OnInit,
  output,
  signal,
} from '@angular/core';
import { RouterModule } from '@angular/router';
import { JsonPipe, NgClass } from '@angular/common';
import { ColType, EradaColumn, Status } from '@core/@models';
import { MenuItem } from 'primeng/api';
import { TableModule } from 'primeng/table';
import { MenuModule } from 'primeng/menu';
import { LocalizeRouterModule } from '@gilsdav/ngx-translate-router';
import { TranslateModule } from '@ngx-translate/core';
import { StatusDirective } from '@shared/_directives';
import { AllBranchesPayload } from '@features/branches';
import { ProgressSpinnerModule } from 'primeng/progressspinner';

@Component({
  selector: 'erada-table',
  standalone: true,
  imports: [
    TableModule,
    RouterModule,
    NgClass,
    MenuModule,
    LocalizeRouterModule,
    TranslateModule,
    StatusDirective,
    JsonPipe,
    ProgressSpinnerModule,
  ],
  templateUrl: './table.component.html',
  styleUrl: './table.component.scss',
})
export class TableComponent implements OnInit {
  constructor() {}

  dataList = input.required<any[]>();
  totalRows = input.required<number>();
  rows = input.required<number>();
  showLoanNumber = input(false);
  cols = input.required<EradaColumn[]>();
  loading = input<boolean>();
  rowsPerPageOptions = signal([5, 10, 20, 30, 40, 50]);
  expandedRowKeys: { [key: string]: boolean } = {};
  moreDetailsList = input<MenuItem[]>();
  statusList = input<{ [key: string | number]: Status }>({});
  public types = ColType;
  paginatorEvent = output<any>();
  payload: AllBranchesPayload = {
    limit: 5,
    page: 1,
  };
  ngOnInit(): void {
    console.log(this.moreDetailsList());
  }

  getStatusColor = computed(() => {
    return (statusId: string | number) => {
      return this.statusList()[statusId];
    };
  });
  toggleRow(rowData: any) {
    const rowKey = rowData.staffId;
    if (this.expandedRowKeys[rowKey]) {
      delete this.expandedRowKeys[rowKey];
    } else {
      this.expandedRowKeys = { [rowKey]: true };
    }
  }

  onRowExpand(event: any) {
    const rowKey = event.data.id;
    this.expandedRowKeys[rowKey] = true;
  }

  onRowCollapse(event: any) {
    const rowKey = event.data.id;
    delete this.expandedRowKeys[rowKey];
  }

  onCustomPage(event: any) {
    const rows = event.rows || this.payload.limit;
    const first = typeof event.first === 'number' ? event.first : 0;

    this.payload = {
      page: Math.floor(first / rows) + 1,
      limit: rows,
    };

    this.paginatorEvent.emit(this.payload);
  }
}
