import { Component, input } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import {
  Chart,
  ChartData,
  ChartOptions,
  ChartType,
  LegendItem,
} from 'chart.js';
import { BaseChartDirective } from 'ng2-charts';

@Component({
  selector: 'erada-chart',
  standalone: true,
  imports: [BaseChartDirective],
  templateUrl: './chart.component.html',
  styleUrl: './chart.component.scss',
})
export class ChartComponent {
  constructor(private translate: TranslateService) {}
  chartType = input.required<ChartType>();
  chartData = input.required<ChartData<ChartType>>();
  customClass = input<string>('');
  customYTick = input<string>('');
  showCustomLegend = input<boolean>(true);
  chartOptions: ChartOptions<ChartType> = {
    responsive: true,
    maintainAspectRatio: false,

    scales: {
      x: {
        beginAtZero: true,
        ticks: {
          color: '#1a1a1a',
          // stepSize: 30,

          font: {
            weight: 'bold',
            size: 10,
            family: 'Noto',
          },
        },
        border: {
          dash: [1, 2],
        },
      },
      y: {
        beginAtZero: true,
        position: this.translate.currentLang === 'ar' ? 'right' : 'left', // Moves the Y-axis to the right
        ticks: {
          maxTicksLimit: 10,
          padding: 15,
          callback: (tickValue: string | number) => {
            if (this.customYTick().trim()) {
              return [
                tickValue.toString(),
                this.translate.instant(this.customYTick()),
              ];
            }
            // Ensure tickValue is handled as a number
            if (typeof tickValue === 'number') {
              if (tickValue >= 1000000) {
                return [
                  (tickValue / 1000000).toString(),
                  this.translate.instant('screens.branches.millions'),
                ];
              }
              if (tickValue >= 1000) {
                return [
                  (tickValue / 1000).toString(),
                  this.translate.instant('screens.branches.thousands'),
                ];
              }
            }
            return tickValue;
          },
          font: {
            weight: 'bold',
            size: 10,
            family: 'Noto',
          },
        },
        border: {
          dash: [1, 2],
        },
      },
    },
    // aspectRatio: 3.3,
    elements: {
      bar: {
        borderWidth: 0,
        borderRadius: 500,
      },
    },
    plugins: {
      legend: {
        reverse: true,
        rtl: this.translate.currentLang === 'ar',

        labels: {
          color: '#1a1a1a',
          font: {
            weight: 'bold',
            size: 10,
            family: 'Noto',
          },
          padding: 20,
          generateLabels: (chart): LegendItem[] => {
            if (this.showCustomLegend()) {
              const labels = (chart.data.labels as (string | number)[]) || []; // Cast to string or number array
              const backgroundColors =
                (chart.data.datasets[0].backgroundColor as string[]) || [];
              return labels.map(
                (label, index): LegendItem => ({
                  text: label.toString() || '', // Display dataset label or default text
                  fillStyle: backgroundColors[index] || 'rgba(0, 0, 0, 0)', // Use dataset background color
                  strokeStyle: undefined, // Remove the stroke style (border)
                  index: index, // The index of the dataset
                })
              );
            } else {
              // If not showing custom legend, return default labels
              return Chart.defaults.plugins.legend.labels.generateLabels(chart); // Call default method
            }
          },
        },
      },
    },
  };
}
