import { Component, input, signal } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { LocalizeRouterModule } from '@gilsdav/ngx-translate-router';
import { TranslateModule } from '@ngx-translate/core';
import { DynamicDialogConfig, DynamicDialogRef } from 'primeng/dynamicdialog';
import { ButtonComponent } from '../button/button.component';

@Component({
  selector: 'app-dynamic-popup',
  standalone: true,
  imports: [
    TranslateModule,
    LocalizeRouterModule,
    RouterModule,
    ButtonComponent,
  ],
  templateUrl: './dynamic-popup.component.html',
  styleUrl: './dynamic-popup.component.scss',
})
export class DynamicPopupComponent {
  icon = signal<string>('');
  title = signal<string>('');
  subTitle = signal<string>('');
  buttonText = signal<string>('');
  routeUrl = signal<string>('');

  constructor(
    private router: Router,
    public config: DynamicDialogConfig,
    private dialogRef: DynamicDialogRef
  ) {
    this.icon.set(this.config.data.icon);
    this.title.set(this.config.data.title);
    this.subTitle.set(this.config.data.subTitle);
    this.buttonText.set(this.config.data.buttonText);
    this.routeUrl.set(this.config.data.routeUrl);
  }

  submit() {
    this.dialogRef.close();
  }
}
