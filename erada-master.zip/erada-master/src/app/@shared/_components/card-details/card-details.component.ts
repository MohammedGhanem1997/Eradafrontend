import { Component, computed, input } from '@angular/core';
import { MenuItem } from 'primeng/api';
import { ToastModule } from 'primeng/toast';
import { ButtonModule } from 'primeng/button';
import { MenuModule } from 'primeng/menu';
import { NgClass, NgFor } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';
import { SectionInterface, Status } from '@core/@models';
import { StatusDirective } from '@shared/_directives';

@Component({
  selector: 'erada-card-details',
  standalone: true,
  imports: [
    ToastModule,
    ButtonModule,
    MenuModule,
    NgFor,
    TranslateModule,
    NgClass,
    StatusDirective,
  ],
  templateUrl: './card-details.component.html',
  styleUrl: './card-details.component.scss',
})
export class CardDetailsComponent {
  items = input<MenuItem[]>();
  subTitle = input<string>('');
  title = input<string>('');
  icon = input<string>();
  sections = input<SectionInterface[]>();
  customClass = input<string>('');
  customClassSections = input<string>('');
  statusList = input<{ [key: string | number]: Status }>({});

  getStatusColor = computed(() => {
    return (statusId: string | number) => {
      return this.statusList()[statusId];
    };
  });
}
