import { Component, input, output } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';
import { ButtonComponent } from '@shared/_components/button/button.component';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [TranslateModule, ButtonComponent],
  templateUrl: './header.component.html',
  styleUrl: './header.component.scss',
})
export class HeaderComponent {
  title = input('');
  userName = input('');
  buttonText = input<string>('');
  image = input('');
  iconButton = input('');
  hideNotification = input(false);
  buttonAction = output<any>();

  addButtonAction(event: any) {
    this.buttonAction.emit(event);
  }
}
