export const NAVBAR = [
    {
        label: 'home',
        icon: 'icon-home',
        route: '/'
    },
    {
        label: 'products',
        icon: 'icon-products',
        route: 'products'
    },
    {
        label: 'pending_requests',
        icon: 'icon-pending requests',
        route: 'pending_requests'
    },
    {
        label: 'customers',
        icon: 'icon-customers',
        route: 'customers'
    },
    {
        label: 'partners',
        icon: 'icon-partners',
        route: 'partners'
    },
    {
        label: 'suppliers',
        icon: 'icon-suppliers',
        route: 'suppliers'
    },
    {
        label: 'branches',
        icon: 'icon-branches',
        route: 'branches'
    },
    {
        label: 'employees',
        icon: 'icon-employees',
        route: 'employees'
    },
    {
        label: 'reports',
        icon: 'icon-reports',
        route: 'reports'
    },
]