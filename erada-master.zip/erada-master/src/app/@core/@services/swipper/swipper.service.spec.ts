import { TestBed } from '@angular/core/testing';

import { SwipperService } from './swipper.service';

describe('SwipperService', () => {
  let service: SwipperService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SwipperService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
