import { FormGroup } from "@angular/forms";
import { CreateBranchInterface } from "@core/@models/_interfaces/branch/create-branch.interface";
import { ControlsOf } from "@core/@utilites";


export type CreateBranchForm = FormGroup<ControlsOf<CreateBranchInterface>>