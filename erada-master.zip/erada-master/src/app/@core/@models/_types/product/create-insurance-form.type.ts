import { FormGroup } from "@angular/forms";
import { CreateInsuranceInterface } from "@core/@models/_interfaces/product/create-insurance.interface";
import { ControlsOf } from "@core/@utilites";

export type CreateInsuranceForm = FormGroup<ControlsOf<CreateInsuranceInterface>>