export interface SearchCriteriaInterface {
     term: string
     option: any 
    }