export interface MenuItemsInterface {
    label: string
    icon?: string
}