export interface FilterValues {
  field: string;
  value: any;
}

export interface DataFilterInterface {
  name: string;
  value: string;
}

export interface EradaFilter {
  label: string;
  placeholder?: string;
  control: any;
  type: string;
  data?: any[];
  optionLabel?: string;
  optionValue?: string;
}
