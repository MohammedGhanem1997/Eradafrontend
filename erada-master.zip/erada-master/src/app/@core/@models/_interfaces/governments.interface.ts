export interface Area {
  name: {
    en: string;
    ar: string;
  };
}

export interface Governorate {
  governorate: {
    en: string;
    ar: string;
  };
  areas: Area[];
}
