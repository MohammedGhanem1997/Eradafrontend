export interface CreatePolicyInterface {
  policyName: string;
  purchaseAmount: number;
  saleAmount: number;
  startDate: Date | null;
  endDate: Date | null;
}
