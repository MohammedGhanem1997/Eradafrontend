export interface PageEvent {
    first: number;
    rows: number;
    page: number;
    pageCount: number;
}