export enum ColType {
  Status = 'status',
  Currency = 'currency',
  Loan = 'loan',
}
