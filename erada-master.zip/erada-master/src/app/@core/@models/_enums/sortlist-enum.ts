export enum SortList {
    ASC = "asc",
    DESC = "desc",
    Alpha = "alpha",
    Time = "time",
}