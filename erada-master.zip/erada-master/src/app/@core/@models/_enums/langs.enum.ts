export enum Langs {
    Arabic = 'ar',
    English = 'en',
  }
  