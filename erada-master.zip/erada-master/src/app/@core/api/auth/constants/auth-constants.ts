import { environment } from "src/environments/environment";

const AUTH_USERS = environment.preDevURL + '';
export const AuthEndpoints = {
    GET_USER: `${AUTH_USERS}`,
}