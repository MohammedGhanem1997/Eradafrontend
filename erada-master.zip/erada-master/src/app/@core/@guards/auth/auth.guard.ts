import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthorizationService } from '@core/api/auth';
import { map } from 'rxjs';

export const authGuard: CanActivateFn = (route, state) => {
  const authService = inject(AuthorizationService);
  const router = inject(Router);

  return authService.getUser().pipe(
    map((res) => {
      if (!res) router.navigate(['']);
      return !!res;
    }),
  );
};
