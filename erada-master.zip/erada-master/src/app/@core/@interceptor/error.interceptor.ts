import { HttpErrorResponse, HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { MessageService } from 'primeng/api';
import { throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

export const ErrorInterceptor: HttpInterceptorFn = (req, next) => {
  const messageService = inject(MessageService);

  return next(req).pipe(
    catchError((error: HttpErrorResponse) => {
      let errorMessage = 'An unknown error occurred';

      if (error.error) {
        if (
          typeof error.error === 'object' &&
          error.error.message &&
          error.error.error
        ) {
          errorMessage = `${error.error.message}`;
        } else if (error.error.error && error.error.error.message) {
          const detailedMessages = [];
          for (const key in error.error.error.message) {
            if (error.error.error.message[key]) {
              detailedMessages.push(`${key} ${error.error.error.message[key]}`);
            }
          }
          console.log(detailedMessages);
          errorMessage = `Error Details: ${detailedMessages.join(', ')}`;
        }
        // Generic error handling if neither format matches
        else {
          errorMessage = error.message || 'An error occurred';
        }
      }
      messageService.add({
        severity: 'error',
        summary: 'Error',
        detail: errorMessage,
        life: 5000,
      });

      // Return an observable with a user-facing error message
      return throwError(() => new Error(errorMessage));
    })
  );
};
