import { TestBed } from '@angular/core/testing';
import { HttpInterceptorFn } from '@angular/common/http';

import { ForbiddenInterceptor } from './forbidden.interceptor';

