export const environment = {
    production: false,
    preDevURL: 'local'
}