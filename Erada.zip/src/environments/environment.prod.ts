export const environment = {
    production: true,
    preDevURL: ''
}