import { Component } from '@angular/core';
import { EradaColumn } from '@core/@models';
import { HomeCardStatisticsComponent, StatusStatisticsComponent, TableComponent } from '@shared/_components';
import { HeaderComponent } from 'src/app/@block';

@Component({
  selector: 'app-customers',
  standalone: true,
  imports: [
    StatusStatisticsComponent,
    HomeCardStatisticsComponent,
    HeaderComponent,
    TableComponent
  ],
  templateUrl: './customers.component.html',
  styleUrl: './customers.component.scss'
})
export class CustomersComponent {

  customersDatalist = [
    { staffId: '2548541',  customerName: 'محمد ابوالنور', nationalId: '21562350215487', mobile: '01118009870', loanNumber: '3', loanAmount: '10000', icon: 'icon-arrow-left.svg', customerLoans : [
      { name: 'قرض متناهي الصغر…', type: 'B2B', amount: '5000', installment: '1000', period: '6', date: '22/3/2023' },
      { name: 'قرض متناهي الصغر…', type: 'B2C', amount: '10000', installment: '1000', period: '5', date: '22/3/2023' },
      { name: 'قرض متناهي الصغر…', type: 'اسلامي', amount: '7000', installment: '1200', period: '12', date: '22/3/2023' }
    ] },
    { staffId: '6523124',  customerName: 'محمد ابوالنور', nationalId: '25632541254128', mobile: '01118009870', loanNumber: '1', loanAmount: '75000', icon: 'icon-arrow-left.svg' },
  ]
  
  customerTableCols: EradaColumn[] = [
    { field: 'staffId', header: 'الرقم التعريفي' },
    { field: 'customerName', header: 'اسم العميل' },
    { field: 'nationalId', header: 'الرقم القومي' },
    { field: 'mobile', header: 'رقم الموبايل' },
    { field: 'loanNumber', header: 'عدد القروض' },
    { field: 'loanAmount', header: 'قيمه القرض' },
    { field: 'icon', header: '' },
  ]

  getEvent(event: any) {
    console.log(event);
  }

}
