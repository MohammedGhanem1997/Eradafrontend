import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ActiveInactiveEmployeesComponent } from './active-inactive-employees.component';

describe('ActiveInactiveEmployeesComponent', () => {
  let component: ActiveInactiveEmployeesComponent;
  let fixture: ComponentFixture<ActiveInactiveEmployeesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ActiveInactiveEmployeesComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ActiveInactiveEmployeesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
