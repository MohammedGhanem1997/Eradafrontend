import { Component, input } from '@angular/core';
import { EradaColumn, EradaFilter, FilterTypeEnum } from '@core/@models';
import { TranslateModule } from '@ngx-translate/core';
import { FilterComponent, SearchInputComponent, TableComponent } from '@shared/_components';
import { MenuItem } from 'primeng/api';
import { MenuModule } from 'primeng/menu';

@Component({
  selector: 'app-active-inactive-employees',
  standalone: true,
  imports: [
    SearchInputComponent,
    TranslateModule,
    MenuModule,
    TableComponent,
    FilterComponent
  ],
  templateUrl: './active-inactive-employees.component.html',
  styleUrl: './active-inactive-employees.component.scss'
})
export class ActiveInactiveEmployeesComponent {

  employeesDatalist = input.required<any[]>()
  employeesTableCols = input.required<EradaColumn[]>()
  moreDetailsOtions = input<MenuItem[]>()

  filterSearchOptions: any[] = [
    { label: 'staffId', id: '1' },
    { label: 'employeeName', id: '1' },
    { label: 'group', id: '1' },
  ]

  onSearch(event: any) {

  }

  filterDataList: EradaFilter[] = [
    {
      label: 'screens.employees_group_details.governorate',
      placeholder: 'screens.employees_group_details.all_governorates',
      control: 'governate',
      type: FilterTypeEnum.dropdwon,
      data: [
      { name: 'القاهره', value: '1' },
      { name: 'الجيزه', value: '2' },
      { name: 'الشرقيه', value: '3' },
      { name: 'المنوفيه', value: '4' }
    ]
    },
    {
      label: 'screens.employees_group_details.area',
      placeholder: 'screens.employees_group_details.all_areas',
      control: 'area',
      type: FilterTypeEnum.dropdwon,
      data: [
        { name: 'السلام', value: '1' },
        { name: 'مصرالجديده', value: '2' },
        { name: 'المطريه', value: '3' },
        { name: 'سرايا القبه', value: '4' }
      ]
    },
    {
      label: 'screens.employees_group_details.breanch_status',
      control: 'branchStatus',
      type: FilterTypeEnum.radioButton,
      data: [
        { name: 'نشط', value: 'active' },
        { name: 'موقوف مؤقتا', value: 'terminate' },
        { name: 'غير نشط', value: 'inActive' },
      ]
    }
  ]

}
