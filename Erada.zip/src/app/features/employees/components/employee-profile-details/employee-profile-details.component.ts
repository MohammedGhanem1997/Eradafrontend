import { Component } from '@angular/core';
import { Status } from '@core/@models';
import { TranslateModule } from '@ngx-translate/core';
import { StatusDirective } from '@shared/_directives';

@Component({
  selector: 'app-employee-profile-details',
  standalone: true,
  imports: [TranslateModule, StatusDirective],
  templateUrl: './employee-profile-details.component.html',
  styleUrl: './employee-profile-details.component.scss',
})
export class EmployeeProfileDetailsComponent {
  statusList = { نشط: Status.Success, 'غير نشط': Status.Error };
}
