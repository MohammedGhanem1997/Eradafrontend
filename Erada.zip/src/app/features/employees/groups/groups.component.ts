import { Component, signal } from '@angular/core';
import { MenuItem } from 'primeng/api';
import { BreadcrumbComponent, CardDetailsComponent, SearchInputComponent, SortButtonComponent } from '@shared/_components';
import { TranslateModule } from '@ngx-translate/core';
import { SearchCriteriaInterface, SortList } from '@core/@models';
import { Router } from '@angular/router';
import { LocalizeRouterService } from '@gilsdav/ngx-translate-router';
import { HeaderComponent } from 'src/app/@block';

@Component({
  selector: 'app-groups',
  standalone: true,
  imports: [
    HeaderComponent,
    BreadcrumbComponent,
    TranslateModule,
    SearchInputComponent,
    SortButtonComponent,
    CardDetailsComponent,
  ],
  templateUrl: './groups.component.html',
  styleUrl: './groups.component.scss',
})
export class GroupsComponent {

  constructor(
    private router: Router,
    private localizeRouterService: LocalizeRouterService
  ) {}


  breadcrumbItems: MenuItem[] = [
    { label: 'screens.employees_groups.employees', routerLink: 'employees'  },
    { label: 'screens.employees_groups.groups'},
  ];
  sortList: MenuItem[] = [
    { label: 'shared.sortList.asc', fragment:  SortList.ASC},
    { label: 'shared.sortList.desc', fragment:  SortList.DESC},
    { label: 'shared.sortList.alpha', fragment:  SortList.Alpha},
    { label: 'shared.sortList.temp', fragment:  SortList.Time},
  ];
  searchFilterOptions = [
    { label: 'الرقم التعريفي', id: 122 },
    { label: 'اسم المستخدم', id: 33 },
    { label: 'اسم الموظف', id: 44 },
  ];
  employeeGroups = [
    {
      title: 'اسم المجموعة يكتب هنا',
      subTitle: '1783497',
      id: 1,
      sections: [
        { label: 'عدد الموظفين', value: 5 },
        { label: 'تاريخ الإنشاء', value: '22/4/2023' },
      ],
    },
    {
      title: 'اسم المجموعة يكتب هنا',
      subTitle: '1783497',
      id: 2,
      sections: [
        { label: 'عدد الموظفين', value: 5 },
        { label: 'تاريخ الإنشاء', value: '22/4/2023' },
      ],
    },
    {
      title: 'اسم المجموعة يكتب هنا',
      subTitle: '1783497',
      id: 3,
      sections: [
        { label: 'عدد الموظفين', value: 5 },
        { label: 'تاريخ الإنشاء', value: '22/4/2023' },
      ],
    },
    {
      title: 'اسم المجموعة يكتب هنا',
      subTitle: '1783497',
      id: 4,
      sections: [
        { label: 'عدد الموظفين', value: 5 },
        { label: 'تاريخ الإنشاء', value: '22/4/2023' },
      ],
    },
    {
      title: 'اسم المجموعة يكتب هنا',
      subTitle: '1783497',
      id: 5,
      sections: [
        { label: 'عدد الموظفين', value: 5 },
        { label: 'تاريخ الإنشاء', value: '22/4/2023' },
      ],
    },
    {
      title: 'اسم المجموعة يكتب هنا',
      subTitle: '1783497',
      id: 6,
      sections: [
        { label: 'عدد الموظفين', value: 5 },
        { label: 'تاريخ الإنشاء', value: '22/4/2023' },
      ],
    },
  ];
  items = signal([
    {
      label: 'screens.employees_groups.menu_showDetails',
      icon: 'icon-note.svg',
      command: () => this.showDetails(1),
    },
    {
      label: 'screens.employees_groups.menu_edit',
      icon: 'icon-edit.svg',
      command: () => console.log('test'),
    },
    {
      label: 'screens.employees_groups.menu_addemployee',
      icon: 'icon-group.svg',
      command: () => console.log('test'),
    },
    {
      label: 'screens.employees_groups.menu_delete',
      icon: 'icon-delete.svg',
      command: () => console.log('test'),
    },
  ]);
  currentLang = signal('');



  showDetails(groupId: number) {
    const translatedRoute = this.localizeRouterService.translateRoute([
      '/employees/groups/group-details',
      groupId,
    ]) as any;
    this.router.navigate(translatedRoute);
  }

  addGroup(event: any) {
    console.log(event);
  }
  onSearch(event: SearchCriteriaInterface) {
    console.log(event.term);
    console.log(event.option);
  }
}
