import { TestBed } from '@angular/core/testing';

import { EmployeesManageStateService } from './employees-manage-state.service';

describe('EmployeesManageStateService', () => {
  let service: EmployeesManageStateService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(EmployeesManageStateService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
