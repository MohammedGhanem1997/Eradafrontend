import { Component, signal } from '@angular/core';
import { MenuItem } from 'primeng/api';
import { BreadcrumbComponent, CardDetailsComponent, SearchInputComponent, SortButtonComponent } from '@shared/_components';
import { TranslateModule } from '@ngx-translate/core';
import { SearchCriteriaInterface, SortList } from '@core/@models';
import { Router } from '@angular/router';
import { LocalizeRouterService } from '@gilsdav/ngx-translate-router';
import { HeaderComponent } from 'src/app/@block';

@Component({
  selector: 'app-roles',
  standalone: true,
  imports: [
    HeaderComponent,
    BreadcrumbComponent,
    TranslateModule,
    SearchInputComponent,
    SortButtonComponent,
    CardDetailsComponent,
  ],
  templateUrl: './roles.component.html',
  styleUrl: './roles.component.scss',
})
export class RolesComponent {
  breadcrumbItems: MenuItem[] = [
    { label: 'screens.employees_roles.employees', routerLink: 'employees' },
    {
      label: 'screens.employees_roles.employees_roles'
    },
  ];
  searchFilterOptions = [
    { label: 'الرقم التعريفي', id: 122 },
    { label: 'اسم المستخدم', id: 33 },
    { label: 'اسم الموظف', id: 44 },
  ];
  employeeRoles = [
    {
      title: 'اسم الدور يكتب هنا',
      subTitle: '1783497',
      sections: [
        { label: 'عدد الموظفين', value: 5 },
        { label: 'تاريخ الإنشاء', value: '22/4/2023' },
      ],
    },
    {
      title: 'اسم الدور يكتب هنا',
      subTitle: '1783497',
      sections: [
        { label: 'عدد الموظفين', value: 5 },
        { label: 'تاريخ الإنشاء', value: '22/4/2023' },
      ],
    },
    {
      title: 'اسم الدور يكتب هنا',
      subTitle: '1783497',
      sections: [
        { label: 'عدد الموظفين', value: 5 },
        { label: 'تاريخ الإنشاء', value: '22/4/2023' },
      ],
    },
    {
      title: 'اسم الدور يكتب هنا',
      subTitle: '1783497',
      sections: [
        { label: 'عدد الموظفين', value: 5 },
        { label: 'تاريخ الإنشاء', value: '22/4/2023' },
      ],
    },
    {
      title: 'اسم الدور يكتب هنا',
      subTitle: '1783497',
      sections: [
        { label: 'عدد الموظفين', value: 5 },
        { label: 'تاريخ الإنشاء', value: '22/4/2023' },
      ],
    },
    {
      title: 'اسم الدور يكتب هنا',
      subTitle: '1783497',
      sections: [
        { label: 'عدد الموظفين', value: 5 },
        { label: 'تاريخ الإنشاء', value: '22/4/2023' },
      ],
    },
  ];
  items = signal([
    {
      label: 'screens.employees_roles.menu_showRole',
      icon: 'icon-linear-book.svg',
      command: () => this.showDetails(1),
    },
  ]);
  sortList: MenuItem[] = [
    { label: 'shared.sortList.asc', fragment:  SortList.ASC},
    { label: 'shared.sortList.desc', fragment:  SortList.DESC},
    { label: 'shared.sortList.alpha', fragment:  SortList.Alpha},
    { label: 'shared.sortList.temp', fragment:  SortList.Time},
  ];

  currentLang = signal('');

  constructor(
    private router: Router,
    private localizeRouterService: LocalizeRouterService
  ) {}
  showDetails(roleId: number) {
    const translatedRoute = this.localizeRouterService.translateRoute([
      '/employees/roles/role-details',
      roleId,
    ]) as any;
    this.router.navigate(translatedRoute);
  }
  onSearch(event: SearchCriteriaInterface) {
    console.log(event.term);
    console.log(event.option);
  }
}
