import { Component } from '@angular/core';
import { EradaColumn, SectionInterface } from '@core/@models';
import { TranslateModule } from '@ngx-translate/core';
import {
  CardDetailsComponent,
  HomeCardStatisticsComponent,
  StatusStatisticsComponent,
} from '@shared/_components';
import { MenuItem } from 'primeng/api';
import { HeaderComponent } from 'src/app/@block';
import { TabViewModule } from 'primeng/tabview';
import { ActiveInactiveEmployeesComponent } from './components/active-inactive-employees/active-inactive-employees.component';
import { EmployeesStatistcsComponent } from './components/employees-statistcs/employees-statistcs.component';
import { ChartData, ChartOptions } from 'chart.js';
import { Router, RouterLink } from '@angular/router';
import {
  LocalizeRouterModule,
  LocalizeRouterService,
} from '@gilsdav/ngx-translate-router';

@Component({
  selector: 'app-employees',
  standalone: true,
  imports: [
    HeaderComponent,
    TranslateModule,
    StatusStatisticsComponent,
    HomeCardStatisticsComponent,
    CardDetailsComponent,
    ActiveInactiveEmployeesComponent,
    TabViewModule,
    EmployeesStatistcsComponent,
    RouterLink,
    LocalizeRouterModule,
  ],
  templateUrl: './employees.component.html',
  styleUrl: './employees.component.scss',
})
export class EmployeesComponent {
  constructor(
    private localizeService: LocalizeRouterService,
    private router: Router
  ) {}
  getEvent(event: any) {
    console.log(event);
  }

  roleSections1: SectionInterface[] = [
    { label: 'عدد الموظفين', value: '150' },
    { label: 'تاريخ الإنشاء', value: '22/4/2023' },
  ];
  roleSections2: SectionInterface[] = [
    { label: 'عدد الموظفين', value: '12' },
    { label: 'تاريخ الإنشاء', value: '2/8/2023' },
  ];
  roleItems: MenuItem[] = [
    {
      label: 'عرض الدور',
      icon: 'icon-book.svg',
      command: () => this.viewRoleDetails(0),
    },
    { label: 'ربط موظف', icon: 'icon-link.svg' },
  ];
  groupItems: MenuItem[] = [
    {
      label: 'عرض المجموعة',
      icon: 'icon-book.svg',
      command: () => this.viewGroupDetails(0),
    },
    { label: 'تعديل', icon: 'icon-edit.svg' },
    { label: 'اضافة موظفين', icon: 'icon-group.svg' },
  ];

  viewRoleDetails(roleId: any) {
    const translatedRoute = this.localizeService.translateRoute([
      '/employees/roles/role-details',
      roleId,
    ]) as any;
    this.router.navigate(translatedRoute);
  }

  viewGroupDetails(groupId: any) {
    const translatedRoute = this.localizeService.translateRoute([
      '/employees/groups/group-details',
      groupId,
    ]) as any;
    this.router.navigate(translatedRoute);
  }

  moreDetailsEmployee: MenuItem[] = [
    {
      label: 'عرض الموظف',
      icon: 'icon-book.svg',
      routerLink: 'employee-details',
    },
    { label: 'اضافة للمجموعه', icon: 'icon-add-policy.svg' },
    { label: 'ربط بالدور', icon: 'icon-link.svg' },
    { label: 'تغير بالدور', icon: 'icon-unlink.svg' },
    { label: 'نقل محفظة', icon: 'icon-wallet.svg' },
  ];

  activeEmployeesDatalist = [
    {
      staffId: '2548541',
      employeeName: 'محمد ابوالنور',
      groupName: 'خدمة العملاء',
      roleName: 'Admin',
      mobile: '01118009870',
      loanNumber: '16',
      icon: 'icon-manage.svg',
    },
    {
      staffId: '6523124',
      employeeName: 'محمد ابوالنور',
      groupName: 'خدمة العملاء',
      roleName: 'Super Admin',
      mobile: '01118009870',
      loanNumber: '3',
      icon: 'icon-manage.svg',
    },
  ];

  activeEmployeesTableCols: EradaColumn[] = [
    { field: 'staffId', header: 'الرقم التعريفي' },
    { field: 'employeeName', header: 'اسم الموظف' },
    { field: 'groupName', header: 'المجموعه' },
    { field: 'roleName', header: 'الدور' },
    { field: 'mobile', header: 'رقم الموبايل' },
    { field: 'loanNumber', header: 'عدد القروض' },
    { field: 'icon', header: '' },
  ];

  inActiveEmployeesDatalist = [
    {
      staffId: '2548541',
      employeeName: 'خديجة ابوالنور',
      groupName: 'الدعم الفني',
      roleName: 'Manager',
      mobile: '01118009870',
      loanNumber: '4',
      icon: 'icon-manage.svg',
    },
    {
      staffId: '6523124',
      employeeName: 'نور مصطفي',
      groupName: 'الدعم الفني',
      roleName: 'Area Manager',
      mobile: '01118009870',
      loanNumber: '12',
      icon: 'icon-manage.svg',
    },
  ];

  inActiveEmployeesTableCols: EradaColumn[] = [
    { field: 'staffId', header: 'الرقم التعريفي' },
    { field: 'employeeName', header: 'اسم الموظف' },
    { field: 'groupName', header: 'المجموعه' },
    { field: 'roleName', header: 'الدور' },
    { field: 'mobile', header: 'رقم الموبايل' },
    { field: 'loanNumber', header: 'عدد القروض' },
    { field: 'icon', header: '' },
  ];

  barChartXLabels: string[] = [
    ' المطرية',
    ' النزهه',
    ' مصر الجديده',
    ' السلام',
    'مدينة نصر ',
    ' التجمع الخامس',
  ];

  barChartData: ChartData<'bar'> = {
    labels: this.barChartXLabels,
    datasets: [
      {
        label: 'المناطق',
        data: [720, 500, 500, 500, 750, 900],
        backgroundColor: '#6DA6E3',

        barThickness: 20,
      },
      {
        label: 'الفروع',
        data: [800, 350, 820, 250, 200, 950],
        backgroundColor: '#3C82C8',

        barThickness: 20,
      },
    ],
  };

  lineChartLabels: string[] = [
    'يناير ',
    'فبراير',
    'مارس',
    'ابريل',
    'مايو',
    'يونيو',
  ];
  lineChartData: ChartData<'line'> = {
    labels: this.lineChartLabels,
    datasets: [
      {
        label: 'محمد ابوالنور',
        data: [0, 20000, 20000, 60000, 60000, 120000],
        backgroundColor: '#35BBC6',
        fill: false,
        tension: 0.5,
        pointRadius: 1,
        borderColor: '#35BBC6',
      },
      {
        label: 'خديجة ابوالنور',
        data: [60000, 30000, 0, 60000, 50000, 120000],
        backgroundColor: '#B2D133',
        fill: false,
        tension: 0.5,
        pointRadius: 1,
        borderColor: '#B2D133',
      },
    ],
  };
}
