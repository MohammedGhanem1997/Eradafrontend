export interface AllEmployee {
  id: string;
  name: string;
  staffId: string;
  phone: string;
  status: boolean;
  role: any;
  branchs: Branch[];
}

export interface Branch {
  id: string;
  branchId: string;
}

export interface AllStaffPayload extends Partial<RemaingPayloadData> {
  page: number;
  limit: number;
}

export interface RemaingPayloadData {
  id: string;
  name: string;
  staffId: string;
  phone: string;
  status: boolean;
  role: any;
}
