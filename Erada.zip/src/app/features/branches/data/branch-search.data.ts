import { EradaColumn, EradaFilter, FilterTypeEnum } from '@core/@models';
import { MenuItem } from 'primeng/api';

export const GroupCols: EradaColumn[] = [
  {
    field: 'id',
    header: 'shared.table.table_staffid',
  },
  {
    field: 'name',
    header: 'screens.branches.branch_name',
  },
  {
    field: 'government',
    header: 'shared.filter.governate',
  },
  { field: 'area', header: 'shared.filter.area' },
  {
    field: 'staffCount',
    header: 'screens.branches.count_employees',
  },
  {
    field: 'num_loans',
    header: 'shared.table.table_loanscount',
  },
  {
    field: 'loans_value',
    header: 'screens.branches.loans_value',
  },
  { field: 'icon', header: '' },
];

export const FilterDataList: EradaFilter[] = [
  {
    label: 'shared.filter.governate',
    placeholder: 'shared.filter.all_governorates',
    control: 'governate',
    type: FilterTypeEnum.dropdwon,
    optionLabel: 'governorate.ar',
    optionValue: 'governorate.en',
    data: [],
  },
  {
    label: 'shared.filter.area',
    placeholder: 'shared.filter.all_areas',
    control: 'area',
    optionLabel: 'name.ar',
    optionValue: 'name.en',
    type: FilterTypeEnum.dropdwon,
    data: [],
  },
];
