import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BranchProductsTableComponent } from './branch-products-table.component';

describe('BranchProductsTableComponent', () => {
  let component: BranchProductsTableComponent;
  let fixture: ComponentFixture<BranchProductsTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [BranchProductsTableComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(BranchProductsTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
