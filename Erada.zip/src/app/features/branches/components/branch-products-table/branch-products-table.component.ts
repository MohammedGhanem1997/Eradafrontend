import { Component, input } from '@angular/core';
import {
  EradaColumn,
  EradaFilter,
  FilterTypeEnum,
  SortList,
  Status,
} from '@core/@models';
import { TranslateModule } from '@ngx-translate/core';
import {
  FilterComponent,
  SearchInputComponent,
  SortButtonComponent,
  TableComponent,
} from '@shared/_components';
import { MenuItem } from 'primeng/api';

@Component({
  selector: 'app-branch-products-table',
  standalone: true,
  imports: [
    TranslateModule,
    SearchInputComponent,
    TableComponent,
    SortButtonComponent,
    FilterComponent,
  ],
  templateUrl: './branch-products-table.component.html',
  styleUrl: './branch-products-table.component.scss',
})
export class BranchProductsTableComponent {
  datalist = input.required<any[]>();
  tableCols = input.required<EradaColumn[]>();
  moreDetailsOtions = input<MenuItem[]>();

  sortList: MenuItem[] = [
    { label: 'shared.sortList.asc', fragment: SortList.ASC },
    { label: 'shared.sortList.desc', fragment: SortList.DESC },
    { label: 'shared.sortList.alpha', fragment: SortList.Alpha },
    { label: 'shared.sortList.temp', fragment: SortList.Time },
  ];
  statusList = {
    نشط: Status.Success,
    'غير نشط': Status.Error,
    مؤرشف: Status.Archived,
  };

  filterSearchOptions: any[] = [{ name: '', value: '' }];
  filterDataList: EradaFilter[] = [
    {
      label: 'shared.filter.governate',
      placeholder: 'shared.filter.all_governorates',
      control: 'governate',
      type: FilterTypeEnum.dropdwon,
      data: [
        { name: 'القاهره', value: '1' },
        { name: 'الجيزه', value: '2' },
        { name: 'الشرقيه', value: '3' },
        { name: 'المنوفيه', value: '4' },
      ],
    },
    {
      label: 'shared.filter.area',
      placeholder: 'shared.filter.all_areas',
      control: 'area',
      type: FilterTypeEnum.dropdwon,
      data: [
        { name: 'السلام', value: '1' },
        { name: 'مصرالجديده', value: '2' },
        { name: 'المطريه', value: '3' },
        { name: 'سرايا القبه', value: '4' },
      ],
    },
    {
      label: 'shared.filter.branch',
      placeholder: 'shared.filter.all_branches',
      control: 'branch',
      type: FilterTypeEnum.dropdwon,
      data: [
        { name: 'السلام', value: '1' },
        { name: 'مصرالجديده', value: '2' },
        { name: 'المطريه', value: '3' },
        { name: 'سرايا القبه', value: '4' },
      ],
    },
    {
      label: 'shared.filter.product_type',
      placeholder: 'shared.filter.all_products',
      control: 'productType',
      type: FilterTypeEnum.dropdwon,
      data: [
        { name: 'السلام', value: '1' },
        { name: 'مصرالجديده', value: '2' },
        { name: 'المطريه', value: '3' },
        { name: 'سرايا القبه', value: '4' },
      ],
    },
    {
      label: 'shared.filter.product_status',
      control: 'productStatus',
      type: FilterTypeEnum.radioButton,
      data: [
        { name: 'نشط', value: 'active' },
        { name: 'غير نشط', value: 'inActive' },
      ],
    },
  ];
  getValue(event: SortList) {}
}
