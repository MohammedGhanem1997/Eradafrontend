import { AsyncPipe } from '@angular/common';
import { Component, OnInit, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import {
  Area,
  CreateBranchForm,
  GlobalResponse,
  Governorate,
  SingleGlobalResponse,
} from '@core/@models';
import { LoadingService } from '@core/@services';
import { GovernatesService } from '@core/@services/governates/governates.service';
import { AllBranches, CreateBranchPayload } from '@features/branches/models';
import { BranchesApiService } from '@features/branches/services';
import { AllEmployee, AllStaffPayload } from '@features/employees/models';
import { EmployeesApiService } from '@features/employees/services';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { ButtonComponent, InputTextComponent } from '@shared/_components';
import { LazyLoadEvent } from 'primeng/api';
import { DropdownModule } from 'primeng/dropdown';
import {
  DialogService,
  DynamicDialogConfig,
  DynamicDialogRef,
} from 'primeng/dynamicdialog';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { of, switchMap, tap } from 'rxjs';

@Component({
  selector: 'app-create-branch',
  standalone: true,
  imports: [
    TranslateModule,
    InputTextComponent,
    ReactiveFormsModule,
    ButtonComponent,
    DropdownModule,
    ProgressSpinnerModule,
    AsyncPipe,
  ],
  templateUrl: './create-branch.component.html',
  styleUrl: './create-branch.component.scss',
  providers: [DialogService],
})
export class CreateBranchComponent implements OnInit {
  branchForm!: CreateBranchForm;
  currentLang = signal('');
  branchId = signal<string>('');
  governates: Governorate[] = [];
  cities: Area[] = [];
  staffPayload: AllStaffPayload = {
    limit: 5,
    page: 1,
  };
  managers: AllEmployee[] = [];
  totalItems = 0;
  initialNameValue: string = '';

  constructor(
    private fb: FormBuilder,
    private governorateService: GovernatesService,
    private translate: TranslateService,
    private employeesApiService: EmployeesApiService,
    private branchApiService: BranchesApiService,
    public dialogService: DialogService,
    private dialogRef: DynamicDialogRef,
    private dialog: DynamicDialogConfig,
    public loadingService: LoadingService
  ) {
    this.currentLang.set(this.translate.currentLang);
  }

  ngOnInit(): void {
    this.intializeForm();
  }

  intializeForm() {
    this.branchId.set(this.dialog.data?.id);
    this.createBranchForm();
    this.getAllGovernates();
    this.loadingService.start(); // Start the loader
    this.getAllEmployees()
      .pipe(
        switchMap(() => {
          if (this.branchId()) {
            return this.loadBranchData(this.branchId()); // Return the observable here
          } else {
            return of(null); // Return an empty observable if branchId is not present
          }
        })
      )
      .subscribe();
    this.setupGovernmentValueChanges();
  }
  setupGovernmentValueChanges() {
    this.branchForm
      .get('government')
      ?.valueChanges.subscribe((selectedGovernate) => {
        this.fetchAreasBasedOnGovernate(selectedGovernate);
      });
  }

  loadBranchData(branchId: string) {
    this.loadingService.start(); // Start the loader
    return this.branchApiService.getBranchById(branchId).pipe(
      tap((res: SingleGlobalResponse<AllBranches>) => {
        if (res.data.government) {
          this.fetchAreasBasedOnGovernate(res.data.government);
        }
        const selectedManager = this.managers.find(
          (m) => m.id === res.data.managerId
        );
        if (!selectedManager) {
          this.getSelectedEmployee(res.data.managerId);
        }
        this.branchForm.patchValue(res.data, { emitEvent: true });
        this.initialNameValue = this.branchForm.get('name')?.value || '';
      }),
      tap({
        complete: () => {
          this.loadingService.stop(); // End the loader
        },
      })
    );
  }
  getSelectedEmployee(employeeId: string): void {
    this.employeesApiService.getEmployeeById(employeeId).subscribe({
      next: (res: SingleGlobalResponse<AllEmployee>) => {
        this.managers = [...this.managers, res.data];
      },
    });
  }
  getAllGovernates() {
    this.governorateService.getData().subscribe((data) => {
      this.governates = data;
    });
  }
  fetchAreasBasedOnGovernate(governate: string) {
    this.branchForm.get('city')?.reset();
    const selectedGovernate = this.governates.find(
      (e) => e.governorate.en === governate
    );

    if (selectedGovernate) {
      this.cities = selectedGovernate.areas;
    } else {
      this.cities = []; // Clear the city options if no governate matches
    }
  }

  getAllEmployees() {
    return this.employeesApiService
      .getAllEmployees({ ...this.staffPayload })
      .pipe(
        tap((res: GlobalResponse<AllEmployee>) => {
          const newItems = res.data.items.filter(
            (item: AllEmployee) => !this.managers.find((m) => m.id === item.id) // Exclude already loaded items
          );

          // Add new items to the dropdown list and track their IDs
          this.managers = [...this.managers, ...newItems];

          this.staffPayload = {
            ...this.staffPayload,
            page: this.staffPayload.page + 1,
          };
          this.totalItems = res.data.meta.totalItems;
        }),
        tap({
          complete: () => {
            this.loadingService.stop(); // End the loader
          },
        })
      );
  }

  loadMoreItems(event: LazyLoadEvent): void {
    if (this.managers.length >= this.totalItems) {
      return;
    }
    this.getAllEmployees().pipe().subscribe();
  }
  createBranchForm() {
    this.branchForm = this.fb.group({
      name: ['', Validators.required],
      government: ['', Validators.required],
      area: ['', Validators.required],
      managerId: ['', Validators.required],
      lat: [''],
      len: [''],
      street: [''],
      city: ['', Validators.required],
      buildingNO: [''],
      landmark: [''],
    });
  }
  onSubmit() {
    if (this.branchForm.invalid) {
      this.branchForm.markAllAsTouched();
      return;
    }
    const payload: CreateBranchPayload = Object.entries(
      this.branchForm.value
    ).reduce((acc, [key, value]) => {
      if (value !== '') {
        if (key === 'name' && value === this.initialNameValue) {
          return acc;
        }
        acc[key as keyof CreateBranchPayload] = value;
      }
      return acc;
    }, {} as CreateBranchPayload);
    if (this.branchId()) {
      this.onEdit(payload);
    } else {
      this.onCreate(payload);
    }
  }
  onCreate(payload: CreateBranchPayload) {
    this.branchApiService.createBranch(payload).subscribe({
      next: (response) => {
        this.dialogRef.close();
        import(
          '@shared/_components/dynamic-popup/dynamic-popup.component'
        ).then((c) => {
          this.dialogService.open(c.DynamicPopupComponent, {
            showHeader: true,
            width: '25vw',
            modal: true,
            styleClass: 'er_p-dialog',
            data: {
              title: 'screens.branches.created_successfully',
              icon: 'icon-confirmation-success.svg',
              buttonText: 'screens.branches.btn_done',
            },
          });
        });
      },
    });
  }
  onEdit(payload: CreateBranchPayload) {
    this.branchApiService.updateBranch(this.branchId(), payload).subscribe({
      next: (response) => {
        this.dialogRef.close();
        import(
          '@shared/_components/dynamic-popup/dynamic-popup.component'
        ).then((c) => {
          this.dialogService.open(c.DynamicPopupComponent, {
            showHeader: true,
            width: '25vw',
            modal: true,
            styleClass: 'er_p-dialog',
            data: {
              title: 'screens.branches.updated_successfully',
              icon: 'icon-confirmation-success.svg',
              buttonText: 'screens.branches.btn_done',
            },
          });
        });
      },
    });
  }
}
