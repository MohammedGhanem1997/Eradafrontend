import { Component, input, OnInit, signal } from '@angular/core';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import {
  BreadcrumbComponent,
  CardDetailsComponent,
  HomeCardStatisticsComponent,
  SearchInputComponent,
  StatusStatisticsComponent,
} from '@shared/_components';
import { ViewDetailsComponent } from '@shared/_components/view-details/view-details.component';
import { MenuItem } from 'primeng/api';
import { TabViewModule } from 'primeng/tabview';
import { BranchesStatusTableComponent } from '../branches-status-table/branches-status-table.component';
import { BranchProductsTableComponent } from '../branch-products-table/branch-products-table.component';
import { DialogService } from 'primeng/dynamicdialog';
import { BranchesApiService } from '@features/branches/services';
import {
  EmployeeTableCols,
  MoreDetailsEmployee,
  MoreDetailsProduct,
  ProductTableCols,
} from '@features/branches/data/branch-details.data';
import { LoadingService } from '@core/@services';
import { AllBranches } from '@features/branches/models';
import { SectionInterface } from '@core/@models';
import { EmployeesApiService } from '@features/employees/services';
import { AllEmployee } from '@features/employees/models';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-branch-details',
  standalone: true,
  imports: [
    TranslateModule,
    BreadcrumbComponent,
    CardDetailsComponent,
    ViewDetailsComponent,
    HomeCardStatisticsComponent,
    StatusStatisticsComponent,
    TabViewModule,
    BranchesStatusTableComponent,
    SearchInputComponent,
    BranchProductsTableComponent,
  ],
  templateUrl: './branch-details.component.html',
  styleUrl: './branch-details.component.scss',
  providers: [DialogService, DatePipe],
})
export class BranchDetailsComponent implements OnInit {
  id = input<string>();

  constructor(
    public dialogService: DialogService,
    private translate: TranslateService,
    private branchApiService: BranchesApiService,
    public loadingService: LoadingService,
    private employeeApiService: EmployeesApiService,
    private datePipe: DatePipe
  ) {}

  haveLoans = signal<boolean>(false);
  branchDetailsData = signal<AllBranches>({} as AllBranches);
  employeeDetailsData = signal<AllEmployee>({} as AllEmployee)
  breadcrumbList = signal<MenuItem[]>([
    { label: 'shared.pages.branches', routerLink: 'branches' },
    { label: 'screens.branches.view_branch_details' },
  ]);
  branchDetailsSections = signal<SectionInterface[]>([
    { label: 'screens.branch_details.governate', value: '' },
    { label: 'screens.branch_details.manager_branch_name', value: '' },
    { label: 'screens.branch_details.manager_mobile_number', value: '' },
    { label: 'screens.branch_details.creator', value: '' },
    { label: 'screens.branch_details.create_date', value: '' },
  ]);

  ngOnInit(): void {
    this.getBranchDetails(this.id()!);
  }

  get productTableCols() {
    return ProductTableCols;
  }

  get employeeTableCols() {
    return EmployeeTableCols;
  }

  get moreDetailsProduct() {
    return MoreDetailsProduct;
  }

  get moreDetailsEmployee() {
    return MoreDetailsEmployee;
  }

  productDatalist = [
    {
      staffId: '2548541',
      productName: ' تمويل متناهي الصغر',
      productType: ' B2B',
      loanNumber: '5',
      loanAmount: '10000',
      productStatus: 'نشط',
      icon: 'icon-manage.svg',
    },
    {
      staffId: '6523124',
      productName: ' تمويل متناهي الصغر',
      productType: ' B2C',
      loanNumber: '6',
      loanAmount: '25000',
      productStatus: 'غير نشط',
      icon: 'icon-manage.svg',
    },
    {
      staffId: '6523124',
      productName: ' تمويل متناهي الصغر',
      productType: ' B2C',
      loanNumber: '6',
      loanAmount: '25000',
      productStatus: 'مؤرشف',
      icon: 'icon-manage.svg',
    },
  ];
  employeeDatalist = [
    {
      staffId: '2548541',
      employeeName: 'خديجة ابوالنور',
      groupName: 'الدعم الفني',
      roleName: 'Manager',
      mobile: '01118009870',
      loanNumber: '4',
      icon: 'icon-manage.svg',
    },
    {
      staffId: '6523124',
      employeeName: 'نور مصطفي',
      groupName: 'الدعم الفني',
      roleName: 'Area Manager',
      mobile: '01118009870',
      loanNumber: '12',
      icon: 'icon-manage.svg',
    },
  ];

  getBranchDetails(branchId: string) {
    this.branchApiService.getBranchById(branchId).subscribe({
      next: (res) => {
        this.getEmployeeDetails(res.data.managerId)
        this.branchDetailsData.set(res.data);
        this.updateBranchSections(res.data);
      },
    });
  }

  getEmployeeDetails(employeeId: string) {
    this.employeeApiService.getEmployeeById(employeeId).subscribe({
      next: (res) => {
        this.employeeDetailsData.set(res.data)
        this.updateBranchSectionsFromEmployee(res.data)
      }
    })
  }

  updateBranchSections(data: AllBranches) {
    this.branchDetailsSections.update(sections => {
      const updatedSections = [...sections];
      const governateIndex = updatedSections.findIndex(s => s.label === 'screens.branch_details.governate');
      const createDateIndex = updatedSections.findIndex(s => s.label === 'screens.branch_details.create_date');
      if (governateIndex !== -1) updatedSections[governateIndex].value = data.government;
      if (createDateIndex !== -1) updatedSections[createDateIndex].value = this.formatDate(data.createdAt);
      return updatedSections;
    });
  }

  updateBranchSectionsFromEmployee(data: AllEmployee) {
    this.branchDetailsSections.update(sections => {
      const updatedSections = [...sections];
      const managerNameIndex = updatedSections.findIndex(s => s.label === 'screens.branch_details.manager_branch_name');
      const managerPhoneIndex = updatedSections.findIndex(s => s.label === 'screens.branch_details.manager_mobile_number');
      if (managerNameIndex !== -1) updatedSections[managerNameIndex].value = data.name;
      if (managerPhoneIndex !== -1) updatedSections[managerPhoneIndex].value = data.phone;
      return updatedSections;
    });
  }
  

  formatDate(date: string): string {
    return this.datePipe.transform(date, 'yyyy/MM/dd') || '';
  }

  onViewDetails(event: any) {
    import('../branch-profile/branch-profile.component').then((c) =>
      this.dialogService.open(c.BranchProfileComponent, {
        styleClass: 'er_p-dialog er_background-p-dialog',
        header:
          this.translate.instant('shared.buttons.details') +
          ' ' +
          this.branchDetailsData().name+', '+this.branchDetailsData().area,
        rtl: true,
        width: '100%',
        height: '100%',
        data: {
          branch: this.branchDetailsData(),
          employee: this.employeeDetailsData()
        }
      })
    );
  }
}
