import { Component, signal } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';
import { SearchInputComponent, SortButtonComponent } from '@shared/_components';
import { LoanCardComponent } from '../loan-card/loan-card.component';
import { PaginatorModule, PaginatorState } from 'primeng/paginator';
import { SortList } from '@core/@models';
import { MenuItem } from 'primeng/api';

@Component({
  selector: 'app-branches-status-table',
  standalone: true,
  imports: [
    TranslateModule,
    SearchInputComponent,
    LoanCardComponent,
    PaginatorModule,
    SortButtonComponent
  ],
  templateUrl: './branches-status-table.component.html',
  styleUrl: './branches-status-table.component.scss'
})
export class BranchesStatusTableComponent {

  filterSearchOptions: any[] = [
    { name: 'الرقم التعريفي', value: 'staffId' },
  ]

  first = signal(0)
  rows = signal(10)

  sortList: MenuItem[] = [
    { label: 'shared.sortList.asc', fragment: SortList.ASC },
    { label: 'shared.sortList.desc', fragment: SortList.DESC },
    { label: 'shared.sortList.alpha', fragment: SortList.Alpha },
    { label: 'shared.sortList.temp', fragment: SortList.Time },
  ]
  

  getValue(event: SortList) {

  }

  onPageChange(event: PaginatorState) {
    if(event.first) {
      this.first.set(event.first);
    }
    if(event.rows) {
      this.rows.set(event.rows);
    }
  }
}
