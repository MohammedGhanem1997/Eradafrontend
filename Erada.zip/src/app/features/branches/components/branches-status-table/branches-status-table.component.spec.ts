import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BranchesStatusTableComponent } from './branches-status-table.component';

describe('BranchesStatusTableComponent', () => {
  let component: BranchesStatusTableComponent;
  let fixture: ComponentFixture<BranchesStatusTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [BranchesStatusTableComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(BranchesStatusTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
