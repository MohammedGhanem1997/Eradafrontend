import { DatePipe } from '@angular/common';
import { Component, signal } from '@angular/core';
import { AllBranches } from '@features/branches/models';
import { AllEmployee } from '@features/employees/models';
import { TranslateModule } from '@ngx-translate/core';
import { DynamicDialogConfig } from 'primeng/dynamicdialog';

@Component({
  selector: 'app-branch-profile',
  standalone: true,
  imports: [TranslateModule, DatePipe],
  templateUrl: './branch-profile.component.html',
  styleUrl: './branch-profile.component.scss',
})
export class BranchProfileComponent {
  branchDetailsData = signal<AllBranches>({} as AllBranches);
  employeeDetailsData = signal<AllEmployee>({} as AllEmployee);

  constructor(private dialog: DynamicDialogConfig) {
    this.branchDetailsData.set(this.dialog.data.branch);
    this.employeeDetailsData.set(this.dialog.data.employee);
  }
}
