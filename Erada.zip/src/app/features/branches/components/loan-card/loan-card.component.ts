import { Component, input } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'app-loan-card',
  standalone: true,
  imports: [
    TranslateModule
  ],
  templateUrl: './loan-card.component.html',
  styleUrl: './loan-card.component.scss'
})
export class LoanCardComponent {

  loanName = input<string>()
  creator = input<string>()
  createDate = input<string>()
  loanAmount = input<string>()
  loanPeriod = input<string>()

}
