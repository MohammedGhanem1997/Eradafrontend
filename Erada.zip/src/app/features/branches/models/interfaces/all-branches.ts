export interface AllBranches {
  id: string;
  name: string;
  status: string;
  managerId: string;
  area: string;
  government: string;
  lat: string;
  len: string;
  street: string;
  city: string;
  buildingNO: string;
  landmark: string;
  updatedAt: string;
  createdAt: string;
}

export interface AllBranchesPayload extends Partial<RemaingPayloadData> {
  page: number;
  limit: number;
}

export interface RemaingPayloadData {
  name: string;
  status: string;
  managerId: string;
  area: string;
  government: string;
  lat: string;
  len: string;
  street: string;
  city: string;
  buildingNO: string;
  landmark: string;
  search: string;
}
export interface BranchStatusStatistics {
  freezed: number;
  active: number;
  closed: number;
  all: number;
}
