export enum BranchStatus {
    Active = 'active',
    Closed = 'closed',
    Freeze = 'freezed'
}