import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {
  AllBranches,
  AllBranchesPayload,
  CreateBranchPayload,
  BranchStatusStatistics,
} from '../models';
import { BranchesEndpoints } from '../constants';
import { GlobalResponse, SingleGlobalResponse } from '@core/@models';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class BranchesApiService {
  constructor(private http: HttpClient) {}

  /**
   * Retrieves all branches based on payload.
   * @param {AllBranchesPayload} data  The payload containing data to get all branches.
   * @returns {Observable<GlobalResponse<AllBranches>>}  An observable that have all branches list.
   */
  getAllBranches(
    data: AllBranchesPayload
  ): Observable<GlobalResponse<AllBranches>> {
    const params = new HttpParams({ fromObject: data as any });
    return this.http.get<GlobalResponse<AllBranches>>(
      BranchesEndpoints.GET_BRANCHES,
      { params }
    );
  }

  /**
   * Create Branch.
   * @param {CreateBranchPayload} data  The payload containing data to save a new branch.
   * @returns {Observable<SingleGlobalResponse<AllBranches>>}  An observable that have saved branch details.
   */
  createBranch(
    data: CreateBranchPayload
  ): Observable<SingleGlobalResponse<AllBranches>> {
    return this.http.post<SingleGlobalResponse<AllBranches>>(
      BranchesEndpoints.CREATE_BRANCH,
      { ...data }
    );
  }

  /**
   * Update Branch.
   * @param {CreateBranchPayload} data The payload containing data to update a branch.
   * @param {string} id   The branch id that will be updated .
   * @returns {Observable<SingleGlobalResponse<AllBranches>>}  An observable that have saved branch details after updated.
   */
  updateBranch(
    id: string,
    data: CreateBranchPayload
  ): Observable<SingleGlobalResponse<AllBranches>> {
    return this.http.patch<SingleGlobalResponse<AllBranches>>(
      `${BranchesEndpoints.CREATE_BRANCH}/${id}`,
      { ...data }
    );
  }

  /**
   * Retrieves specific branch details based on id.
   * @param {string} id  The payload containing id to get specific branch details.
   * @returns {Observable<SingleGlobalResponse<AllBranches>>}  An observable that have specific branch details.
   */
  getBranchById(id: string): Observable<SingleGlobalResponse<AllBranches>> {
    return this.http.get<SingleGlobalResponse<AllBranches>>(
      `${BranchesEndpoints.GET_SPECIFIC_BRANCH}/${id}`
    );
  }

  /**
   * Changes branch status based on this status {active, closed, freezed}.
   * @param {enum} status  The payload containing status to update specific branch status.
   * @returns {Observable<SingleGlobalResponse<{ message: string }>>}  An observable that have specific message of succses or faluire.
   */
  changeBranchStatus(
    id: string,
    status: string
  ): Observable<SingleGlobalResponse<{ message: string }>> {
    return this.http.patch<SingleGlobalResponse<{ message: string }>>(
      `${BranchesEndpoints.UPDATE_BRANCH_STATUS}/${id}`,
      { status }
    );
  }
  /**
   * get branches statistics
   * @returns {Observable<SingleGlobalResponse<BranchStatusStatistics>>}  An observable that have statistics data .
   */
  getBranchesStatus(): Observable<
    SingleGlobalResponse<BranchStatusStatistics>
  > {
    return this.http.get<SingleGlobalResponse<BranchStatusStatistics>>(
      `${BranchesEndpoints.GET_BRANCHES_STATUS}`
    );
  }
}
