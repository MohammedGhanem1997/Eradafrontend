import { Component, OnInit, signal } from '@angular/core';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { HeaderComponent } from 'src/app/@block';
import { DialogService, DynamicDialogModule } from 'primeng/dynamicdialog';
import { HomeCardStatisticsComponent } from '@shared/_components/statistics/home-card-statistics/home-card-statistics.component';
import { StatusStatisticsComponent } from '@shared/_components/statistics/status-statistics/status-statistics.component';
import { TabViewModule } from 'primeng/tabview';
import { BranchSearchContainerComponent } from './components/branch-search-container/branch-search-container.component';
import { EradaFilter, FilterTypeEnum, Status } from '@core/@models';
import { StatusDirective } from '@shared/_directives';
import { ButtonComponent } from '@shared/_components/button/button.component';
import { DropdownModule } from 'primeng/dropdown';
import { ReactiveFormsModule } from '@angular/forms';
import { CalendarModule } from 'primeng/calendar';
import { AppDatepickerComponent } from '@shared/_components/app-datepicker/app-datepicker.component';
import { ChartData } from 'chart.js';
import { BaseChartDirective } from 'ng2-charts';
import { ChartComponent } from '@shared/_components/chart/chart.component';
import { FilterComponent } from '@shared/_components/filter/filter.component';
import { BranchStatus } from './models';
import { BranchesApiService } from './services';

@Component({
  selector: 'app-branches',
  standalone: true,
  imports: [
    HeaderComponent,
    TranslateModule,
    DynamicDialogModule,
    HomeCardStatisticsComponent,
    StatusStatisticsComponent,
    TabViewModule,
    BranchSearchContainerComponent,
    StatusDirective,
    ButtonComponent,
    DropdownModule,
    ReactiveFormsModule,
    CalendarModule,
    AppDatepickerComponent,
    BaseChartDirective,
    ChartComponent,
    FilterComponent,
  ],
  templateUrl: './branches.component.html',
  styleUrl: './branches.component.scss',
  providers: [DialogService],
})
export class BranchesComponent implements OnInit {
  constructor(
    public dialogService: DialogService,
    private translate: TranslateService,
    private branchApiService: BranchesApiService
  ) {}
  chartStatus = Status.Success;
  showFilter = signal(false);
  activeIndex = 0;
  haveLoans = signal<boolean>(false);
  statisticsData: {
    active: number;
    all: number;
    closed: number;
    freezed: number;
  } = {
    active: 0,
    all: 0,
    closed: 0,
    freezed: 0,
  };

  filterDataList: EradaFilter[] = [
    {
      label: 'shared.filter.date',
      control: 'date',
      type: FilterTypeEnum.date,
    },
    {
      label: 'shared.filter.governate',
      placeholder: 'shared.filter.all_governorates',
      control: 'governate',
      type: FilterTypeEnum.dropdwon,
      data: [
        { name: 'القاهره', value: '1' },
        { name: 'الجيزه', value: '2' },
        { name: 'الشرقيه', value: '3' },
        { name: 'المنوفيه', value: '4' },
      ],
    },
    {
      label: 'shared.filter.area',
      placeholder: 'shared.filter.all_areas',
      control: 'area',
      type: FilterTypeEnum.dropdwon,
      data: [
        { name: 'السلام', value: '1' },
        { name: 'مصرالجديده', value: '2' },
        { name: 'المطريه', value: '3' },
        { name: 'سرايا القبه', value: '4' },
      ],
    },
  ];

  barChartXLabels: string[] = [
    'اسم الفرع',
    'اسم الفرع',
    'اسم الفرع',
    'اسم الفرع',
    'اسم الفرع',
    'اسم الفرع',
    'اسم الفرع',
    'اسم الفرع',
  ];

  barChartData: ChartData<'bar'> = {
    // yLabels: this.barChartYLabels,
    labels: this.barChartXLabels,

    datasets: [
      {
        // label: 'القروض النشطة',
        data: [720000, 500000, 500000, 500000, 750000, 1000000, 500000, 300000],
        backgroundColor: [
          '#8A79E2',
          '#B2D133',
          '#DD8941',
          '#35BBC6',
          '#DB73AB',
          '#D8BC5E',
          '#799DE2',
          '#F48A7A',
        ],
        barThickness: 20,
      },
    ],
  };
  ngOnInit(): void {
    this.getStatisticsData();
  }

  getStatisticsData() {
    this.branchApiService.getBranchesStatus().subscribe({
      next: (data) => {
        this.statisticsData = data.data;
      },
    });
  }
  onTabChange(event: any) {
    this.activeIndex = event.index;
  }

  BranchStatus = BranchStatus;

  get activeBranchStatus() {
    switch (this.activeIndex) {
      case 0:
        return BranchStatus.Active;
      case 1:
        return BranchStatus.Freeze;
      case 2:
        return BranchStatus.Closed;
      default:
        return BranchStatus.Active;
    }
  }

  getEvent(event: any) {
    import('./components/create-branch/create-branch.component').then((c) =>
      this.dialogService.open(c.CreateBranchComponent, {
        styleClass: 'er_p-dialog er_background-p-dialog',
        header: this.translate.instant('shared.buttons.create_new_branch'),
        rtl: true,
        width: '100%',
        height: '100%',
      })
    );
  }
}
