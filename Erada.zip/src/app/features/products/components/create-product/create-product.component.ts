import { Component } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';
import { NgClass } from '@angular/common';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  ReactiveFormsModule,
} from '@angular/forms';
import { ProductInfoComponent } from './components/product-info/product-info.component';
import {
  CreateProductForm,
  IScore,
  ProductInfo,
  RepaymentFrequency,
} from '@core/@models';
import { FinancialInfoComponent } from './components/financial-info/financial-info.component';

@Component({
  selector: 'app-create-product',
  standalone: true,
  imports: [
    TranslateModule,
    NgClass,
    ReactiveFormsModule,
    ProductInfoComponent,
    FinancialInfoComponent,
  ],
  templateUrl: './create-product.component.html',
  styleUrl: './create-product.component.scss',
})
export class CreateProductComponent {
  productForm!: CreateProductForm;

  constructor(private fb: FormBuilder) {
    this.initializeForm();
  }

  selectedTab: number = 0;
  menuItems = [
    'screens.create_product.menu_product_info',
    'screens.create_product.menu_financial_info',
    'screens.create_product.menu_product_fees',
    'screens.create_product.menu_incentives_offers',
    'screens.create_product.menu_loan_conditions',
    'screens.create_product.menu_fines_delays',
    'screens.create_product.menu_attachments',
    'screens.create_product.menu_workflow',
  ];
  private createProductInfoFormGroup(): ProductInfo {
    return this.fb.group({
      name: new FormControl<string>(''),
      type: new FormControl<string>(''),
      operatingField: new FormControl<string>(''),
      branch: new FormControl<string>(''),
      requiresGuarantor: new FormControl<boolean>(false),
      guarantorCount: new FormControl<Array<string>>([]),
      insuranceCompany: new FormControl<string>(''),
      insurancePolicy: new FormControl<string>(''),
      partners: new FormControl<string>(''),
      suppliers: new FormControl<string>(''),
    });
  }
  private createRepaymentFreq(): RepaymentFrequency {
    return this.fb.group({
      repaymentFrequencyUnit: new FormControl<string>(''),
      repaymentFrequencyDuration: new FormControl<string>(''),
      minProductDurationUnit: new FormControl<string>(''),
      minProductDuration: new FormControl<string>(''),
      maxProductDurationUnit: new FormControl<string>(''),
      maxProductDuration: new FormControl<string>(''),
      productStartDate: new FormControl<Date[] | null>(null),
      productEndDate: new FormControl<Date[] | null>(null),
    });
  }
  private createIScoreFormGroup(): IScore {
    return this.fb.group({
      requiresCreditScore: new FormControl<boolean>(false),
      minCreditScore: new FormControl<number | null>(null),
      maxCreditScore: new FormControl<number | null>(null),
    });
  }
  private initializeForm(): void {
    this.productForm = this.fb.group({
      productInfo: this.createProductInfoFormGroup(),
      repaymentFrequency: this.createRepaymentFreq(),
      iScore: this.createIScoreFormGroup(),
    }) as CreateProductForm;
  }
  getFormGroup(groupName: string): FormGroup {
    return this.productForm.get(groupName) as FormGroup;
  }

  onSelect(index: number): void {
    this.selectedTab = index;
  }
  onCreate() {
    if (this.productForm.valid) {
      console.log(this.productForm.value);
    } else {
      console.log('error validation');
    }
  }
}
