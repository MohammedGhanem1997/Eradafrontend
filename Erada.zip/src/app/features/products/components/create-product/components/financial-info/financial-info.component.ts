import { NgClass } from '@angular/common';
import { Component, input } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { CreateProductForm } from '@core/@models';
import { TranslateModule } from '@ngx-translate/core';
import {
  AppDatepickerComponent,
  InputTextComponent,
} from '@shared/_components';
import { InputNumberComponent } from '@shared/_components/input-number/input-number.component';
import { DropdownModule } from 'primeng/dropdown';
import { InputSwitchModule } from 'primeng/inputswitch';

@Component({
  selector: 'erada-financial-info',
  standalone: true,
  imports: [
    InputTextComponent,
    TranslateModule,
    DropdownModule,
    ReactiveFormsModule,
    InputSwitchModule,
    NgClass,
    AppDatepickerComponent,
    InputNumberComponent,
  ],
  templateUrl: './financial-info.component.html',
  styleUrl: './financial-info.component.scss',
})
export class FinancialInfoComponent {
  form = input.required<CreateProductForm>();

  fieldOperations = [
    { label: 'لوريم ايبسوم هو نموذج', value: 'test' },
    { label: 'لوريم ايبسوم هو نموذج', value: 'test1' },
    { label: 'لوريم ايبسوم هو نموذج', value: 'test2' },
    { label: 'لوريم ايبسوم هو نموذج', value: 'test3' },
  ];

  getFormGroup(groupName: string): FormGroup {
    return this.form().get(groupName) as FormGroup;
  }
  getControl(controlName: string, groupName: string): FormControl {
    const group = this.getFormGroup(groupName);
    const control = group.get(controlName);
    return control as FormControl;
  }
}
