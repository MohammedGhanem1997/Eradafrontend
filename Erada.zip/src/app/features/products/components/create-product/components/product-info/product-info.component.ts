import { Component, input } from '@angular/core';
import { InputTextComponent } from '../../../../../../@shared/_components/input-text/input-text.component';
import { TranslateModule } from '@ngx-translate/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { DropdownModule } from 'primeng/dropdown';
import { CreateProductForm } from '@core/@models';
import { InputSwitchModule } from 'primeng/inputswitch';
import { MultiSelectModule } from 'primeng/multiselect';
import { NgClass } from '@angular/common';
import { AppDatepickerComponent } from '../../../../../../@shared/_components/app-datepicker/app-datepicker.component';
import { InputNumberComponent } from '../../../../../../@shared/_components/input-number/input-number.component';

@Component({
  selector: 'erada-product-info',
  standalone: true,
  imports: [
    InputTextComponent,
    TranslateModule,
    DropdownModule,
    ReactiveFormsModule,
    InputSwitchModule,
    MultiSelectModule,
    NgClass,
    AppDatepickerComponent,
    InputNumberComponent,
  ],
  templateUrl: './product-info.component.html',
  styleUrl: './product-info.component.scss',
})
export class ProductInfoComponent {
  form = input.required<CreateProductForm>();
  productTypes = [
    { label: 'B2B', value: 'B2B' },
    { label: 'B2C', value: 'B2C' },
    { label: 'اسلامي', value: 'islamic' },
  ];
  fieldOperations = [
    { label: 'لوريم ايبسوم هو نموذج', value: 'test' },
    { label: 'لوريم ايبسوم هو نموذج', value: 'test1' },
    { label: 'لوريم ايبسوم هو نموذج', value: 'test2' },
    { label: 'لوريم ايبسوم هو نموذج', value: 'test3' },
  ];

  getFormGroup(groupName: string): FormGroup {
    return this.form().get(groupName) as FormGroup;
  }
  getControl(controlName: string, groupName: string): FormControl {
    const group = this.getFormGroup(groupName);
    const control = group.get(controlName);
    return control as FormControl;
  }
}
