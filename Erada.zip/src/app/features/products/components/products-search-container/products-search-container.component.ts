import { Component, input } from '@angular/core';
import { SearchInputComponent } from '../../../../@shared/_components/search-input/search-input.component';
import { FilterComponent } from '../../../../@shared/_components/filter/filter.component';
import {
  ColType,
  EradaColumn,
  EradaFilter,
  FilterTypeEnum,
  SearchCriteriaInterface,
  SortList,
} from '@core/@models';
import { TranslateModule } from '@ngx-translate/core';
import { SortButtonComponent } from '../../../../@shared/_components/sort-button/sort-button.component';
import { MenuItem } from 'primeng/api';
import { TableComponent } from '../../../../@shared/_components/table/table.component';

@Component({
  selector: 'app-products-search-container',
  standalone: true,
  imports: [
    SearchInputComponent,
    FilterComponent,
    TranslateModule,
    SortButtonComponent,
    TableComponent,
  ],
  templateUrl: './products-search-container.component.html',
  styleUrl: './products-search-container.component.scss',
})
export class ProductsSearchContainerComponent {
  productStatusId = input.required<number>();
  searchFilterOptions = [
    { label: 'الرقم التعريفي', id: 122 },
    { label: 'اسم المستخدم', id: 33 },
    { label: 'اسم الموظف', id: 44 },
  ];
  filterDataList: EradaFilter[] = [
    {
      label: 'shared.filter.governate',
      placeholder: 'shared.filter.all_governorates',
      control: 'governate',
      type: FilterTypeEnum.dropdwon,
      data: [
        { name: 'القاهره', value: '1' },
        { name: 'الجيزه', value: '2' },
        { name: 'الشرقيه', value: '3' },
        { name: 'المنوفيه', value: '4' },
      ],
    },
    {
      label: 'shared.filter.area',
      placeholder: 'shared.filter.all_areas',
      control: 'area',
      type: FilterTypeEnum.dropdwon,
      data: [
        { name: 'السلام', value: '1' },
        { name: 'مصرالجديده', value: '2' },
        { name: 'المطريه', value: '3' },
        { name: 'سرايا القبه', value: '4' },
      ],
    },
    {
      label: 'shared.filter.branch',
      placeholder: 'shared.filter.all_branches',
      control: 'branch',
      type: FilterTypeEnum.dropdwon,
      data: [
        { name: 'السلام', value: '1' },
        { name: 'مصرالجديده', value: '2' },
        { name: 'المطريه', value: '3' },
        { name: 'سرايا القبه', value: '4' },
      ],
    },
    {
      label: 'shared.filter.product_type',
      placeholder: 'shared.filter.all_products',
      control: 'productType',
      type: FilterTypeEnum.dropdwon,
      data: [
        { name: 'السلام', value: '1' },
        { name: 'مصرالجديده', value: '2' },
        { name: 'المطريه', value: '3' },
        { name: 'سرايا القبه', value: '4' },
      ],
    },
    {
      label: 'shared.filter.product_status',
      control: 'productStatus',
      type: FilterTypeEnum.radioButton,
      data: [
        { name: 'نشط', value: 'active' },
        { name: 'غير نشط', value: 'inActive' },
      ],
    },
  ];
  sortList: MenuItem[] = [
    { label: 'shared.sortList.asc', fragment: SortList.ASC },
    { label: 'shared.sortList.desc', fragment: SortList.DESC },
    { label: 'shared.sortList.alpha', fragment: SortList.Alpha },
    { label: 'shared.sortList.temp', fragment: SortList.Time },
  ];
  productCols: EradaColumn[] = [
    {
      field: 'staffId',
      header: 'shared.table.table_staffid',
    },
    {
      field: 'employeeName',
      header: 'screens.products.product_name',
    },
    {
      field: 'groupName',
      header: 'screens.products.product_type',
    },
    {
      field: 'status',
      header: 'screens.products.publications_count',
      label: 'screens.products.publications',
    },
    {
      field: 'mobile',
      header: 'screens.products.sub_product_count',
      label: 'screens.products.products',
    },
    {
      field: 'loanNumber',
      header: 'shared.table.table_loanscount',
      type: ColType.Loan,
    },
    {
      field: 'status',
      header: 'shared.table.table_loans_value',
      type: ColType.Currency,
    },
    { field: 'icon', header: '' },
  ];
  productsDatalist = [
    {
      staffId: '2548541',
      employeeName: 'خديجة ابوالنور',
      groupName: 'الدعم الفني',
      loanAmount: 1000,
      status: 1,
      roleName: 'Manager',
      mobile: '100',
      loanNumber: '4',
      icon: 'icon-manage.svg',
    },
    {
      staffId: '6523124',
      employeeName: 'نور مصطفي',
      loanAmount: 10000,
      status: 2,
      groupName: 'الدعم الفني',
      roleName: 'Area Manager',
      mobile: '100',
      loanNumber: '12',
      icon: 'icon-manage.svg',
    },
  ];
  moreDetailsOptions: MenuItem[] = [
    {
      label: 'screens.products.show_product',
      icon: 'icon-book.svg',
      // routerLink: '/product/branch-details',
    },
    {
      label: 'screens.products.edit_product',
      icon: 'icon-edit.svg',
    },
    {
      label: 'screens.products.add_sub_product',
      icon: 'icon-add-sub-product.svg',
    },
    {
      label: 'screens.products.link',
      icon: 'icon-link.svg',
    },
  ];
  getValue(event: SortList) {}

  onSearch(event: SearchCriteriaInterface) {
    console.log(event.term);
    console.log(event.option);
  }
}
