import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductsSearchContainerComponent } from './products-search-container.component';

describe('ProductsSearchContainerComponent', () => {
  let component: ProductsSearchContainerComponent;
  let fixture: ComponentFixture<ProductsSearchContainerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ProductsSearchContainerComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ProductsSearchContainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
