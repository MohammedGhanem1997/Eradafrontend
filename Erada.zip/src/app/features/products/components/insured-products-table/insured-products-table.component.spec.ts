import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InsuredProductsTableComponent } from './insured-products-table.component';

describe('InsuredProductsTableComponent', () => {
  let component: InsuredProductsTableComponent;
  let fixture: ComponentFixture<InsuredProductsTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [InsuredProductsTableComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(InsuredProductsTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
