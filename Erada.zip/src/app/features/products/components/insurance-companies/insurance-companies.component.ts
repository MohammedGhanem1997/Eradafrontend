import { Component } from '@angular/core';
import { Router } from '@angular/router';
import {
  SearchCriteriaInterface,
  SectionInterface,
  SortList,
  Status,
} from '@core/@models';
import { LocalizeRouterService } from '@gilsdav/ngx-translate-router';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import {
  BreadcrumbComponent,
  CardDetailsComponent,
  SearchInputComponent,
  SortButtonComponent,
} from '@shared/_components';
import { MenuItem } from 'primeng/api';
import { DialogService } from 'primeng/dynamicdialog';
import { HeaderComponent } from 'src/app/@block';

@Component({
  selector: 'app-insurance-companies',
  standalone: true,
  imports: [
    HeaderComponent,
    BreadcrumbComponent,
    CardDetailsComponent,
    SearchInputComponent,
    TranslateModule,
    SortButtonComponent,
  ],
  templateUrl: './insurance-companies.component.html',
  styleUrl: './insurance-companies.component.scss',
  providers: [DialogService],
})
export class InsuranceCompaniesComponent {
  constructor(
    private localizeRouterService: LocalizeRouterService,
    private router: Router,
    public dialogService: DialogService,
    private translate: TranslateService
  ) {}
  breadcrumbItems: MenuItem[] = [
    { label: 'shared.pages.products', routerLink: 'products' },
    { label: 'screens.products.insurance_companies' },
  ];

  sortList: MenuItem[] = [
    { label: 'shared.sortList.asc', fragment: SortList.ASC },
    { label: 'shared.sortList.desc', fragment: SortList.DESC },
    { label: 'shared.sortList.alpha', fragment: SortList.Alpha },
    { label: 'shared.sortList.temp', fragment: SortList.Time },
  ];

  searchFilterOptions = [
    { label: 'الرقم التعريفي', id: 122 },
    { label: 'اسم المستخدم', id: 33 },
    { label: 'اسم الموظف', id: 44 },
  ];

  items: MenuItem[] = [
    {
      label: 'عرض الشركة',
      icon: 'icon-book.svg',
      command: () => this.showDetails(1),
    },
    {
      label: 'إضافة وثيقة',
      icon: 'add-circle.svg',
      command: () => this.createInsurancePolicy(),
    },
    {
      label: 'تعديل',
      icon: 'icon-edit.svg',
      command: () => this.editInsuranceCompany(),
    },
    { label: 'أرشفة الشركة', icon: 'icon-archived-company.svg' },
  ];

  sections: SectionInterface[] = [
    { label: 'حالة الشركة', value: 'نشط', type: 'status' },
    { label: 'عدد الوثائق', value: '8' },
    { label: 'تاريخ الانشاء', value: '16/5/2024' },
  ];

  statusList = { نشط: Status.Success, 'غير نشط': Status.Error };
  showDetails(companyId: number) {
    const translatedRoute = this.localizeRouterService.translateRoute([
      '/products/insurance-details/',
      companyId,
    ]) as any;
    this.router.navigate(translatedRoute);
  }
  addInsurance(event: any) {}

  onSearch(event: SearchCriteriaInterface) {}
  createInsurancePolicy() {
    import('../../components/create-policy/create-policy.component').then((c) =>
      this.dialogService.open(c.CreatePolicyComponent, {
        styleClass: 'er_p-dialog er_background-p-dialog',
        header: this.translate.instant(
          'screens.insurance_details.menu_create_policy'
        ),
        rtl: true,
        width: '100%',
        height: '100%',
      })
    );
  }
  editInsuranceCompany() {
    import('../../components/create-insurance/create-insurance.component').then(
      (c) =>
        this.dialogService.open(c.CreateInsuranceComponent, {
          styleClass: 'er_p-dialog er_background-p-dialog',
          header: this.translate.instant(
            'screens.products.edit_insurance_company'
          ),
          rtl: true,
          width: '100%',
          height: '100%',
          data: {
            id: '10',
          },
        })
    );
  }
}
