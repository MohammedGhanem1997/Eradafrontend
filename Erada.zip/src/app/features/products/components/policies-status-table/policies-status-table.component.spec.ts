import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PoliciesStatusTableComponent } from './policies-status-table.component';

describe('PoliciesStatusCardComponent', () => {
  let component: PoliciesStatusTableComponent;
  let fixture: ComponentFixture<PoliciesStatusTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PoliciesStatusTableComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(PoliciesStatusTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
