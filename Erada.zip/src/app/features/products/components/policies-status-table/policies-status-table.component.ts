import { Component, signal } from '@angular/core';
import { SortList } from '@core/@models';
import { TranslateModule } from '@ngx-translate/core';
import { SearchInputComponent, SortButtonComponent } from '@shared/_components';
import { MenuItem } from 'primeng/api';
import { PaginatorModule, PaginatorState } from 'primeng/paginator';
import { LoanCardComponent } from '../loan-card/loan-card.component';

@Component({
  selector: 'app-policies-status-table',
  standalone: true,
  imports: [
    TranslateModule,
    SearchInputComponent,
    LoanCardComponent,
    PaginatorModule,
    SortButtonComponent
  ],
  templateUrl: './policies-status-table.component.html',
  styleUrl: './policies-status-table.component.scss'
})
export class PoliciesStatusTableComponent {

  filterSearchOptions: any[] = [
    { name: 'الرقم التعريفي', value: 'staffId' },
  ]

  first = signal(0)
  rows = signal(10)

  sortList: MenuItem[] = [
    { label: 'shared.sortList.asc', fragment: SortList.ASC },
    { label: 'shared.sortList.desc', fragment: SortList.DESC },
    { label: 'shared.sortList.alpha', fragment: SortList.Alpha },
    { label: 'shared.sortList.temp', fragment: SortList.Time },
  ]
  

  getValue(event: SortList) {

  }

  onPageChange(event: PaginatorState) {
    if(event.first) {
      this.first.set(event.first);
    }
    if(event.rows) {
      this.rows.set(event.rows);
    }
  }

}
