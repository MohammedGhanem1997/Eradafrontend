import { Component, signal } from '@angular/core';
import { HeaderComponent } from '../../../../@block/header/header.component';
import { BreadcrumbComponent } from '../../../../@shared/_components/breadcrumb/breadcrumb.component';
import { MenuItem } from 'primeng/api';
import { CardDetailsComponent } from '../../../../@shared/_components/card-details/card-details.component';
import {
  ColType,
  EradaColumn,
  SearchCriteriaInterface,
  SectionInterface,
  SortList,
  Status,
} from '@core/@models';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { HomeCardStatisticsComponent } from '../../../../@shared/_components/statistics/home-card-statistics/home-card-statistics.component';
import { StatusStatisticsComponent } from '../../../../@shared/_components/statistics/status-statistics/status-statistics.component';
import { SortButtonComponent } from '../../../../@shared/_components/sort-button/sort-button.component';
import { SearchInputComponent } from '../../../../@shared/_components/search-input/search-input.component';
import { TableComponent } from '../../../../@shared/_components/table/table.component';
import { DialogService, DynamicDialogModule } from 'primeng/dynamicdialog';
import { JsonPipe } from '@angular/common';

@Component({
  selector: 'app-insurance-details',
  standalone: true,
  imports: [
    HeaderComponent,
    BreadcrumbComponent,
    CardDetailsComponent,
    TranslateModule,
    HomeCardStatisticsComponent,
    StatusStatisticsComponent,
    SortButtonComponent,
    SearchInputComponent,
    TableComponent,
    DynamicDialogModule,
    JsonPipe,
  ],
  templateUrl: './insurance-details.component.html',
  styleUrl: './insurance-details.component.scss',
  providers: [DialogService],
})
export class InsuranceDetailsComponent {
  constructor(
    public dialogService: DialogService,
    private translate: TranslateService
  ) {}
  breadcrumbItems: MenuItem[] = [
    { label: 'shared.pages.products', routerLink: 'products' },
    { label: 'اسم شركة التأمين يكتب هنا' },
  ];
  items = signal([
    {
      label: 'screens.insurance_details.menu_create_policy',
      icon: 'add-circle.svg',
      command: () => this.createInsurancePolicy(),
    },
    {
      label: 'screens.insurance_details.menu_edit',
      icon: 'icon-edit.svg',
      command: () => this.editInsuranceCompany(),
    },
    {
      label: 'screens.insurance_details.menu_archive_company',
      icon: 'icon-archived-company.svg',
      command: () => console.log('test'),
    },
  ]);
  searchFilterOptions = [
    { label: 'الرقم التعريفي', id: 122 },
    { label: 'اسم المستخدم', id: 33 },
    { label: 'اسم الموظف', id: 44 },
  ];
  statusList = { نشط: Status.Success, 'غير نشط': Status.Error };
  companyDetailsSections: SectionInterface[] = [
    {
      label: 'screens.insurance_details.company_status',
      value: 'نشط',
      type: 'status',
    },
    {
      label: 'screens.insurance_details.bank_name',
      value: 'البنك الاهلى المصرى',
    },
    {
      label: 'screens.insurance_details.company_account_no',
      value: 123456789123,
    },
    {
      label: 'screens.insurance_details.erada_account_no',
      value: 123456789123,
    },
    { label: 'screens.insurance_details.create_date', value: '22/4/2023' },
    { label: 'screens.insurance_details.created_by', value: 'محمد أحمد السقا' },
  ];
  sortList: MenuItem[] = [
    { label: 'shared.sortList.asc', fragment: SortList.ASC },
    { label: 'shared.sortList.desc', fragment: SortList.DESC },
    { label: 'shared.sortList.alpha', fragment: SortList.Alpha },
    { label: 'shared.sortList.temp', fragment: SortList.Time },
  ];
  company = {
    title: 'اسم شركة التأمين يكتب هنا',
    subTitle: '1783497',
    id: 1,
  };
  policiesCols: EradaColumn[] = [
    {
      field: 'staffId',
      header: 'shared.table.table_staffid',
    },
    {
      field: 'roleName',
      header: 'shared.table.table_policyname',
    },
    {
      field: 'groupName',
      header: 'shared.table.table_purchase_amount',
      type: ColType.Currency,
    },
    {
      field: 'employeeName',
      header: 'shared.table.table_sale_amount',
      type: ColType.Currency,
    },
    {
      field: 'loanNumber',
      header: 'shared.table.table_products_count',
      type: ColType.Loan,
    },
    {
      field: 'employee_status',
      header: 'shared.table.table_loans_value',
      type: ColType.Currency,
    },
    { field: 'icon', header: '' },
  ];
  policiesDatalist = [
    {
      staffId: '2548541',
      employeeName: 5000,
      groupName: 5000,
      employee_status: '10,000',
      status: 1,
      roleName: 'اسم الوثيقة يكتب هنا',
      mobile: '01118009870',
      loanNumber: '4',
      icon: 'icon-manage.svg',
    },
    {
      staffId: '6523124',
      employeeName: 5000,
      employee_status: '10,000',
      status: 2,
      groupName: 5000,
      roleName: 'اسم الوثيقة يكتب هنا',
      mobile: '01118009870',
      loanNumber: '12',
      icon: 'icon-manage.svg',
    },
  ];
  moreDetailsOptions: MenuItem[] = [
    {
      label: 'screens.insurance_details.show_policy',
      icon: 'icon-book.svg',
      routerLink: '/products/policy_details',
    },
    {
      label: 'screens.insurance_details.menu_edit',
      icon: 'icon-edit.svg',
      command: () => this.updateInsurancePolicy(),
    },
  ];

  onSearch(event: SearchCriteriaInterface) {
    console.log(event.term);
    console.log(event.option);
  }

  updateInsurancePolicy() {
    import('../../components/create-policy/create-policy.component').then((c) =>
      this.dialogService.open(c.CreatePolicyComponent, {
        styleClass: 'er_p-dialog er_background-p-dialog',
        header: this.translate.instant('screens.insurance_details.edit_policy'),
        rtl: true,
        width: '100%',
        height: '100%',
        data: {
          id: 1,
        },
        focusOnShow: false,
      })
    );
  }
  createInsurancePolicy() {
    import('../../components/create-policy/create-policy.component').then((c) =>
      this.dialogService.open(c.CreatePolicyComponent, {
        styleClass: 'er_p-dialog er_background-p-dialog',
        header: this.translate.instant(
          'screens.insurance_details.menu_create_policy'
        ),
        rtl: true,
        width: '100%',
        height: '100%',
      })
    );
  }
  editInsuranceCompany() {
    import('../../components/create-insurance/create-insurance.component').then(
      (c) =>
        this.dialogService.open(c.CreateInsuranceComponent, {
          styleClass: 'er_p-dialog er_background-p-dialog',
          header: this.translate.instant(
            'screens.products.edit_insurance_company'
          ),
          rtl: true,
          width: '100%',
          height: '100%',
          data: {
            id: '10',
          },
        })
    );
  }
}
