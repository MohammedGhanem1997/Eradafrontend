import { Component } from '@angular/core';
import { ColType, EradaColumn, EradaFilter, FilterTypeEnum, SectionInterface, SortList, Status } from '@core/@models';
import { InsuredProductsTableComponent } from '@features/products/components/insured-products-table/insured-products-table.component';
import { PoliciesStatusTableComponent } from '@features/products/components/policies-status-table/policies-status-table.component';
import { TranslateModule } from '@ngx-translate/core';
import { BreadcrumbComponent, CardDetailsComponent, StatusStatisticsComponent, HomeCardStatisticsComponent, TableComponent, SearchInputComponent, SortButtonComponent, FilterComponent } from '@shared/_components';
import { MenuItem } from 'primeng/api';
import { DialogService, DynamicDialogModule } from 'primeng/dynamicdialog';
import { TabViewModule } from 'primeng/tabview';

@Component({
  selector: 'app-policy-details',
  standalone: true,
  imports: [
    TranslateModule,
    BreadcrumbComponent,
    CardDetailsComponent,
    StatusStatisticsComponent,
    DynamicDialogModule,
    HomeCardStatisticsComponent,
    TabViewModule,
    PoliciesStatusTableComponent,
    InsuredProductsTableComponent
  ],
  templateUrl: './policy-details.component.html',
  styleUrl: './policy-details.component.scss',
  providers: [DialogService],
})
export class PolicyDetailsComponent {

  breadcrumbList: MenuItem[] = [
    { label: 'shared.pages.products', routerLink: 'products' },
    { label: 'شركة التأمين', routerLink: 'products/insurance-details' },
    { label: 'الوثيقة' },
  ];

  detailsSections: SectionInterface[] = [
    { label: 'مبلغ الشراء', value: '2000' },
    { label: 'مبلغ البيع', value: '2500' },
    { label: 'تاريخ بدء الوثيقة', value: '18/9/2024' },
    { label: 'تاريخ انتهاء الوثيقة', value: '5/10/2024' },
    { label: 'المنشئ', value: 'محمد' },
    { label: 'تاريخ الإنشاء', value: '12/10/2024' }
  ];

  detailsItems: MenuItem[] = [
    { label: 'تعديل', icon: 'icon-edit.svg', command: () =>  this.openEditDialog()},
  ];

  
  tableCols : EradaColumn[] = [
    { field: 'staffId', header: 'الرقم التعريفي' },
    { field: 'productName', header: ' اسم المنتج' },
    { field: 'productType', header: 'نوع المنتج' },
    { field: 'loanNumber', header: 'عدد القروض' },
    { field: 'loanAmount', header: 'قيمة القروض' },
    { field: 'productStatus', header: 'حالة المنتج', type: ColType.Status },
    { field: 'icon', header: '' },
  ]

  datalist = [
    {
      staffId: '2548541',
      productName: ' تمويل متناهي الصغر',
      productType: ' B2B',
      loanNumber: '5',
      loanAmount: '10000',
      productStatus: 'نشط',
      icon: 'icon-manage.svg',
    }
  ]

  moreDetailsPolicies: MenuItem[] = [
    {
      label: 'عرض المنتج',
      icon: 'icon-book.svg',
      routerLink: '',
    },
    { label: 'تعديل', icon: 'icon-edit.svg' },
    { label: 'اضافة منتج فرعي', icon: 'icon-add-sub-product.svg' },
    { label: 'فك الربط', icon: 'icon-unlink.svg' },
  ];

  openEditDialog() {

  }



}
