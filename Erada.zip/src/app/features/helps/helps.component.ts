import { Component } from '@angular/core';

@Component({
  selector: 'app-helps',
  standalone: true,
  imports: [],
  templateUrl: './helps.component.html',
  styleUrl: './helps.component.scss'
})
export class HelpsComponent {

}
