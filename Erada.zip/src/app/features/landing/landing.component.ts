import { Component, signal } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';
import { HomeCardStatisticsComponent } from '@shared/_components';
import { ChartOptions, ChartData } from 'chart.js';
import { BaseChartDirective } from 'ng2-charts';
import { HeaderComponent } from 'src/app/@block';
import { SideNavComponent } from 'src/app/@block/side-nav/side-nav.component';

@Component({
  selector: 'app-landing',
  standalone: true,
  imports: [
    TranslateModule,
    BaseChartDirective,
    SideNavComponent,
    HomeCardStatisticsComponent,
    HeaderComponent
],
  templateUrl: './landing.component.html',
  styleUrl: './landing.component.css',
})
export class LandingComponent {

  doughnutChartLabels: string[] = [
    'Label 1',
    'Label 2',
    'Label 3',
    'Label 4',
    'Label 5',
  ];
  doughnutChartOptions: ChartOptions<'doughnut'> = {
    responsive: true,
    cutout: '75%',
    aspectRatio: 3,
    radius: '100%',
  };
  doughnutChartData: ChartData<'doughnut'> = {
    labels: this.doughnutChartLabels,
    datasets: [
      {
        data: [30, 50, 20, 35, 60],
        backgroundColor: [
          '#FF6384',
          '#36A2EB',
          '#FFCE90',
          '#FFAE16',
          '#F0CE56',
        ],
        hoverBackgroundColor: [
          '#FF6384',
          '#36A2EB',
          '#FFCE56',
          '#EFC056',
          '#FFCA65',
        ],
        borderRadius: 50,
        borderWidth: 10,
      },
    ],
  };

  barChartXLabels: string[] = ['يناير ', 'فبراير ', 'مارس ', 'ابريل ', 'مايو'];
  barChartYLabels: string[] = ['A 1', 'B 2', 'C 3', 'D 4', 'E 5'];
  barChartOptions: ChartOptions<'bar'> = {
    responsive: true,
    aspectRatio: 3,
    elements: {
      bar: {
        borderWidth: 2,
        borderRadius: 500,
      },
    },
    plugins: {
      legend: {
        fullSize: true,
      },
    },
  };
  barChartData: ChartData<'bar'> = {
    yLabels: this.barChartYLabels,
    xLabels: this.barChartXLabels,
    datasets: [
      {
        label: 'القروض النشطة',
        data: [30, 50, 20, 35, 60],
        backgroundColor: [
          '#D2D2D2',
          '#36A2EB',
          '#FFCA65',
          '#E5E5E5BC',
          '#6DA6E3',
        ],
        barThickness: 20,
      },
      {
        label: 'القروض الجاهزة للصرف',
        data: [25, 55, 40, 15, 40],
        backgroundColor: [
          '#D2D2D2',
          '#D2D2D2',
          '#FFCE99',
          '#E5E5E5BC',
          '#6DA6E3',
        ],
        barThickness: 20,
      },
      {
        label: 'القروض قيد المراجعة',
        data: [65, 75, 45, 25, 30],
        backgroundColor: [
          '#D2D2D2',
          '#36A2EB',
          '#D2D2D2',
          '#E5E5E5BC',
          '#6DA6E3',
        ],

        barThickness: 20,
      },
    ],
  };

  lineChartLabels: string[] = [
    'Label ',
    'Label 2',
    'Label 3',
    'Label 4',
    'Label 5',
    'Label 5',
    'Label 5',
    'Label 5',
    'Label 5',
    'Label 5',
    'Label 5',
    'Label 5',
  ];
  lineChartOptions: ChartOptions<'line'> = {
    responsive: true,
    aspectRatio: 3,
    elements: {
      line: {
        borderWidth: 3,
      },
    },
  };
  lineChartData: ChartData<'line'> = {
    labels: this.lineChartLabels,
    xLabels: this.lineChartLabels,
    yLabels: this.lineChartLabels,
    datasets: [
      {
        label: 'Fully Rounded',
        data: [0, 20, 20, 60, 60, 120, 180, 120, 125, 105, 110, 170],
        fill: false,
        tension: 0.5,
        pointRadius: 3,
        borderColor: '#FFCA65',
        borderDashOffset: 10,
      },
      {
        label: 'Fully Radius',
        data: [60, 30, 0, 60, 50, 120, 180, 10, 155, 105, 100, 70],
        fill: false,
        tension: 0.5,
        pointRadius: 3,
        borderColor: '#FF6380',
      },
    ],
    
  };

  getEvent(event: any) {
    console.log(event);
    
  }

}
