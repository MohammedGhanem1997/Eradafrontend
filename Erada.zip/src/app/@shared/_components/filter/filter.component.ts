import { Component, input, OnInit, output, signal } from '@angular/core';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { ButtonComponent } from '../button/button.component';
import { RadioButtonModule } from 'primeng/radiobutton';
import { DropdownModule } from 'primeng/dropdown';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { FilterValues, EradaFilter, FilterTypeEnum } from '@core/@models';
import { AppDatepickerComponent } from '../app-datepicker/app-datepicker.component';

@Component({
  selector: 'erada-filter',
  standalone: true,
  imports: [
    TranslateModule,
    ButtonComponent,
    RadioButtonModule,
    DropdownModule,
    ReactiveFormsModule,
    AppDatepickerComponent,
  ],
  templateUrl: './filter.component.html',
  styleUrl: './filter.component.scss',
})
export class FilterComponent implements OnInit {
  dataList = input.required<EradaFilter[]>();
  filterApplied = output<FilterValues[]>();
  showFilter = signal(false);
  filterForm!: FormGroup;
  filterValues = signal<FilterValues[]>([]);
  get FilterType() {
    return FilterTypeEnum;
  }

  constructor(private fb: FormBuilder, private translate: TranslateService) {}

  ngOnInit(): void {
    this.createFilterForm();
    if (this.filterForm.get('governate')) {
      this.filterForm
        .get('governate')
        ?.valueChanges.subscribe((selectedGovernate) => {
          this.filterForm.get('area')?.reset();
          this.fetchAreasBasedOnGovernate(selectedGovernate);
        });
    }
  }
  fetchAreasBasedOnGovernate(governate: string) {
    const areas = this.getAreasForGovernate(governate);
    const areaFilter = this.dataList().find(
      (filter) => filter.control === 'area'
    );
    if (areaFilter) {
      areaFilter.data = areas;
    }
  }
  getAreasForGovernate(governate: string): any[] {
    const governates = this.dataList()
      .find((filter) => filter.control === 'governate')
      ?.data?.filter((e) => e.governorate.en === governate);
    return governates?.[0]?.areas || [];
  }
  createFilterForm() {
    const formGroup = {} as { [key: string]: any };
    this.dataList()?.forEach((i) => {
      formGroup[i.control] = [null];
    });
    this.filterForm = this.fb.group(formGroup);
  }
  toggleFilter() {
    this.showFilter.set(!this.showFilter());
  }

  onFilter() {
    this.showFilter.set(false);
    const newFilterValues: Array<FilterValues> = [];
    Object.keys(this.filterForm.controls).forEach((key) => {
      const controlValue = this.filterForm.get(key)?.value;
      if (controlValue !== null && controlValue !== '') {
        const fieldType = this.dataList().filter((e) => e.control === key)[0];
        let value = controlValue;
        if (fieldType) {
          if (fieldType.type === FilterTypeEnum.date) {
            value = controlValue
              .map((dateString: string) => {
                const date = new Date(dateString);
                const month = date.getMonth();
                const year = date.getFullYear();
                const months = this.translate.instant('locale.monthNames');

                return `${months[month]}-${year}`;
              })
              .join(',');
          }
          if (
            fieldType.type === FilterTypeEnum.dropdwon ||
            fieldType.type === FilterTypeEnum.radioButton
          ) {
            value = controlValue;
          }
        }

        newFilterValues.push({
          field: key,
          value: value,
        });
      }
    });
    console.log(newFilterValues);
    this.filterValues.set(newFilterValues);
    this.filterApplied.emit(newFilterValues);
  }
  deleteFilters() {
    this.filterForm.reset();
    this.filterValues.set([]);
    this.filterApplied.emit([]);
  }
  removeFilter(field: string) {
    const control = this.filterForm.get(field);
    if (control) {
      control.reset(); // Resets the field to its initial value
      const newFilterValues = this.filterValues().filter(
        (items) => items.field !== field
      );
      this.filterValues.set(newFilterValues);
      this.filterApplied.emit(newFilterValues);
    }
  }
}
