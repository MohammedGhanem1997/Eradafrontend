import { NgClass } from '@angular/common';
import {
  Component,
  computed,
  Input,
  input,
  signal,
  Signal,
} from '@angular/core';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'erada-input-text',
  standalone: true,
  imports: [TranslateModule, ReactiveFormsModule, NgClass],
  templateUrl: './input-text.component.html',
  styleUrl: './input-text.component.scss',
})
export class InputTextComponent {
  @Input() control!: FormControl<string>;
  customClass = input<string>();
  id = input<string>();
  placeholder = input.required<string>();
  validations = input<{ [key: string]: string }>({});
  isPassword = input(false);
  showPassword = signal(true);

  get errorMessage(): string | null {
    if (this.control.errors && this.control.touched) {
      for (const errorKey in this.control.errors) {
        return this.validations()[errorKey] || null;
      }
    }
    return null;
  }

  toggleShowPassword() {
    this.showPassword.update((v) => (v = !v));
  }

  toggleShowConfirmPassword() {
    this.showPassword.update((v) => (v = !v));
  }
}
