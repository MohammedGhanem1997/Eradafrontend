import { Component, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { GoogleMapsModule, MapMarker } from '@angular/google-maps';

interface CustomMarker {
  position: google.maps.LatLngLiteral;
  label: {
    color: string;
    text: string;
  };
}

@Component({
  selector: 'app-maps',
  standalone: true,
  imports: [GoogleMapsModule],
  templateUrl: './maps.component.html',
  styleUrl: './maps.component.scss'
})
export class MapsComponent {

  zoom = 6;
  center: google.maps.LatLngLiteral = { lat: 30.03222240819783, lng: 31.261172713167465 };
  markers: CustomMarker[] = [];

  addMarker(event: google.maps.MapMouseEvent) {
    if (event.latLng != null) {
      this.markers.push({
        position: event.latLng.toJSON(),
        label: {
          color: 'blue',
          text: 'Marker',
        },
      });
      console.log(event.latLng.toJSON());
    }
  }

  updateCenter(lat: number, lng: number) {
    this.center = { lat, lng };
  }

  getGovernateName(lat: number, lng: number) {
    const geocoder = new google.maps.Geocoder();
    geocoder.geocode(
      { location: { lat, lng } },
      (results, status) => {
        if (status === 'OK' && results && results.length > 0) {
          console.log(results[0].address_components);
        }
      }
    );
  }


  mapClick(event: google.maps.MapMouseEvent | any) {
    if(event.latLng) {
      const latLng = event.latLng.toJSON();
      this.getGovernateName(latLng.lat, latLng.lng);
      this.addMarker(event)
    }
  }

}
