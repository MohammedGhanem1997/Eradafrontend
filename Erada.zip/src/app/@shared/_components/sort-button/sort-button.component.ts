import { Component, input, output, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MenuItemsInterface, SortList } from '@core/@models';
import { TranslateModule } from '@ngx-translate/core';
import { MenuItem } from 'primeng/api';
import { Dropdown, DropdownModule } from 'primeng/dropdown';
import { MenuModule } from 'primeng/menu';

@Component({
  selector: 'erada-sort-button',
  standalone: true,
  imports: [MenuModule, TranslateModule, DropdownModule, FormsModule],
  templateUrl: './sort-button.component.html',
  styleUrl: './sort-button.component.scss',
})
export class SortButtonComponent {
  sortList = input.required<MenuItem[]>();
  outputEvent = output<SortList>();
  selectedOption = signal(null);

  onSelect(value: SortList) {
    this.outputEvent.emit(value);
  }
  toggleDropdown(dropdown: Dropdown) {
    if (dropdown.overlayVisible) {
      dropdown.hide();
    } else {
      dropdown.show();
    }
  }
}
