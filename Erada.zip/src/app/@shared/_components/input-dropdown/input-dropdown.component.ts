import { Component, input } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';
import { DropdownModule } from 'primeng/dropdown';


@Component({
  selector: 'erada-input-dropdown',
  standalone: true,
  imports: [
    TranslateModule,
    DropdownModule
  ],
  templateUrl: './input-dropdown.component.html',
  styleUrl: './input-dropdown.component.scss'
})
export class InputDropdownComponent {

  dataList = input<any[]>()
  placeholder = input.required<string>()
  label = input<string>()
  id = input<string>()

}
