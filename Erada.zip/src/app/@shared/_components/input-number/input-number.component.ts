import { Component, input } from '@angular/core';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';
import { InputNumberModule } from 'primeng/inputnumber';

@Component({
  selector: 'erada-input-number',
  standalone: true,
  imports: [InputNumberModule, ReactiveFormsModule, TranslateModule],
  templateUrl: './input-number.component.html',
  styleUrl: './input-number.component.scss',
})
export class InputNumberComponent {
  control = input.required<FormControl<number>>();
  id = input<string>();
  inputId = input<string>('minmaxfraction');
  mode = input<string>('decimal');
  minFractionDigits = input<string>('2');
  maxFractionDigits = input<string>('5');
  showCurrency = input<boolean>(true);
}
