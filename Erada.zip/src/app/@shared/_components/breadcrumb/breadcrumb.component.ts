import { NgClass, NgIf } from '@angular/common';
import { Component, input, signal } from '@angular/core';
import { RouterModule } from '@angular/router';
import { LocalizeRouterModule } from '@gilsdav/ngx-translate-router';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { MenuItem } from 'primeng/api';
import { BreadcrumbModule } from 'primeng/breadcrumb';

@Component({
  selector: 'erada-breadcrumb',
  standalone: true,
  imports: [
    NgClass,
    NgIf,
    BreadcrumbModule,
    TranslateModule,
    RouterModule,
    LocalizeRouterModule
  ],
  templateUrl: './breadcrumb.component.html',
  styleUrl: './breadcrumb.component.scss',
})
export class BreadcrumbComponent {
  items = input.required<MenuItem[]>();
  currentLang = signal('');
  constructor(public translateService: TranslateService) {
    this.currentLang.set(this.translateService.currentLang);
  }
}
