import { NgClass } from '@angular/common';
import { Component, input, signal } from '@angular/core';
import { FormGroup, ReactiveFormsModule } from '@angular/forms';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { CalendarModule } from 'primeng/calendar';

@Component({
  selector: 'erada-datepicker',
  standalone: true,
  imports: [CalendarModule, ReactiveFormsModule, TranslateModule, NgClass],
  templateUrl: './app-datepicker.component.html',
  styleUrl: './app-datepicker.component.scss',
})
export class AppDatepickerComponent {
  formGroup = input.required<FormGroup>();
  controlName = input.required<string>();
  isRange = input<boolean>(false); // Flag for range selection
  dateFormat = input<string>('dd/mm/yy'); // Default date format
  view = input<'month' | 'date'>('month'); // Set default view to 'month'
  placeholder = input<string>('shared.filter.date_placeholder');
  currentLang = signal('');
  id = input<string>();
  appendTo = input<string | null>(null);
  customClass = input<string>('');

  constructor(public translateService: TranslateService) {
    this.currentLang.set(this.translateService.currentLang);
  }
}
