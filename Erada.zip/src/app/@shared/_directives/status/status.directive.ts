import {
  Directive,
  ElementRef,
  Input,
  Renderer2,
  SimpleChanges,
} from '@angular/core';
import { Status } from '@core/@models';

@Directive({
  selector: '[appStatus]',
  standalone: true,
})
export class StatusDirective {
  @Input('appStatus') status: Status = Status.Success;

  constructor(private el: ElementRef, private renderer: Renderer2) {}
  ngOnChanges(changes: SimpleChanges): void {
    if (changes['status']) {
      this.updateStatusClass(this.status);
    }
  }
  private updateStatusClass(status: Status): void {
    // Remove any previously applied status class
    const tailwindClasses: { [key in Status]: string[] } = {
      [Status.Success]: ['bg-er-bg-success', 'text-er-success'],
      [Status.Error]: ['bg-er-bg-error', 'text-er-status-red'],
      [Status.Warning]: ['bg-yellow-500', 'text-er-warning'],
      [Status.Archived]: ['bg-er-bg-purple', 'text-er-status-blue'],
    };

    // Remove all possible status classes
    Object.values(tailwindClasses)
      .flat()
      .forEach((cls) => {
        this.renderer.removeClass(this.el.nativeElement, cls);
      });

    // Add the new class based on status
    const classesToAdd = tailwindClasses[status];
    if (classesToAdd) {
      classesToAdd.forEach((cls) => {
        this.renderer.addClass(this.el.nativeElement, cls);
      });
    }
  }
}
