import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import { TranslateModule } from '@ngx-translate/core';
import { NAVBAR } from './navbar-data';
import { LocalizeRouterModule } from '@gilsdav/ngx-translate-router';
import { BadgeModule } from 'primeng/badge';
@Component({
  selector: 'app-side-nav',
  standalone: true,
  imports: [
    RouterModule,
    TranslateModule,
    LocalizeRouterModule,
    BadgeModule
  ],
  templateUrl: './side-nav.component.html',
  styleUrl: './side-nav.component.scss'
})
export class SideNavComponent {

  get navbarList() {
    return NAVBAR
  }

}
