import {ElementRef} from '@angular/core';

export function scrollToFirstInvalidControl(form: ElementRef<HTMLFormElement>) {
  const nativeElement = form.nativeElement;

  const firstInvalidControl =
    nativeElement.getElementsByClassName('ng-invalid')[0];

  firstInvalidControl.scrollIntoView({
    block: 'center',
  });
}
