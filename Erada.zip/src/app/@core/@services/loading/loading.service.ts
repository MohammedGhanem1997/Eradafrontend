import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoadingService {
  private busyRequestCount = new BehaviorSubject(false)
  loaderStatus$: Observable<boolean | null> = this.busyRequestCount.asObservable()

  start() {
    if (!this.busyRequestCount.value) this.busyRequestCount.next(true)
  }

  stop() {
    if (this.busyRequestCount.value) this.busyRequestCount.next(false)
  }
}
