import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { PrimeNGConfig } from 'primeng/api';
import { firstValueFrom, map } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AppInitializeService {
  constructor(
    private translateService: TranslateService,
    private http: HttpClient,
    private primengConfig: PrimeNGConfig
  ) {}

  initialize(): Promise<any> {
    const activeLang = this.translateService.currentLang ?? 'en';
    return Promise.all([firstValueFrom(this.loadTranslation(activeLang))]);
  }

  loadTranslation(lang: string) {
    return this.http.get<any>(`assets/i18n/${lang}.json`).pipe(
      map((response: any) => {
        this.translateService.setTranslation(lang, response);
        this.translateService.setDefaultLang('ar');
        this.translateService.use(lang);
        this.primengConfig.setTranslation(response.locale);
        document.documentElement.lang = lang;
        document.documentElement.dir = lang == 'en' ? 'ltr' : 'rtl';
      })
    );
  }
}
