import { Injectable } from '@angular/core';
import { register } from 'swiper/element';
@Injectable({
  providedIn: 'root'
})
export class SwipperService {
  constructor() {
    register()
  }
}
