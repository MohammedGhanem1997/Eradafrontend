export enum FilterTypeEnum {
    dropdwon = 'DROPDOWN',
    text = 'TEXT',
    radioButton = 'RADIOBUTTON',
    date = 'DATE'
}