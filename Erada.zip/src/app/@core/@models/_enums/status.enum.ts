export enum Status {
  Success = 'success',
  Error = 'error',
  Warning = 'warning',
  Archived = 'archived',
}
