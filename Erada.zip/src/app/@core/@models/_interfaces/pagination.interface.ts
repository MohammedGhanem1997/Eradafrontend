export interface PaginationInterface {
    currentPage: number
    itemCount: number
    itemsPerPage: number
    totalItems: number
    totalPages:number
}