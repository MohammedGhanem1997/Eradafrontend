export interface SectionInterface {
  label: string;
  value: string | number;
  type?: 'status';
}
