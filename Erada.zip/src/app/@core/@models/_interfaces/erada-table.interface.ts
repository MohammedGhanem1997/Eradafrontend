import { ColType } from '../_enums/col-types.enum';

export interface EradaColumn {
  field: string;
  header: string;
  type?: ColType;
  label?: string;
}
