export interface CreateBranchInterface {
  name: string;
  government: string;
  area: string;
  managerId: string;
  lat: string;
  len: string;
  street: string;
  city: string;
  buildingNO: string;
  landmark: string;
}
