export interface ProductInfoInterface {
  name: string;
  type: string;
  operatingField: string;
  branch: string;
  requiresGuarantor: boolean;
  guarantorCount: Array<string> | null;
  insuranceCompany: string | null;
  insurancePolicy: string | null;
  partners: string;
  suppliers: string;
}
export interface RepaymentFrequencyInterface {
  repaymentFrequencyUnit: string;
  repaymentFrequencyDuration: string;
  minProductDurationUnit: string;
  minProductDuration: string;
  maxProductDurationUnit: string;
  maxProductDuration: string;
  productStartDate: Date[] | null;
  productEndDate: Date[] | null;
}

export interface IScoreInterface {
  requiresCreditScore: boolean;
  minCreditScore: number;
  maxCreditScore: number;
}
