export interface CreateInsuranceInterface {
    compnayName: string
    bankName: string
    companyAccountNo: string
    eradaAccountNo: string
}