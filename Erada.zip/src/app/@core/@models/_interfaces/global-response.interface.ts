import { PaginationInterface } from './pagination.interface';

export interface DataInterface<T> {
  items: T[];
  meta: PaginationInterface;
}

export interface GlobalResponse<T> {
  status: number;
  data: DataInterface<T>;
}
export interface SingleGlobalResponse<T> {
  status: number;
  data: T;
}
