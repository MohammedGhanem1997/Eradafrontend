import { FormArray, FormGroup } from '@angular/forms';
import { CreatePolicyInterface } from '@core/@models/_interfaces/insurance/create-policy.interface';
import { ControlsOf } from '@core/@utilites';

export type CreatePolicyItem = FormGroup<ControlsOf<CreatePolicyInterface>>;
export type CreatePolicyForm = FormGroup<{
  items: FormArray<CreatePolicyItem>;
}>;
