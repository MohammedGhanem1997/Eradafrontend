import { FormGroup } from '@angular/forms';
import {
  IScoreInterface,
  ProductInfoInterface,
  RepaymentFrequencyInterface,
} from '@core/@models/_interfaces/product/create-product.interface';
import { ControlsOf } from '@core/@utilites';

export type CreateProductForm = FormGroup<{
  productInfo: ProductInfo;
  repaymentFrequency: RepaymentFrequency;
  iScore: IScore;
}>;
export type ProductInfo = FormGroup<ControlsOf<ProductInfoInterface>>;
export type RepaymentFrequency = FormGroup<
  ControlsOf<RepaymentFrequencyInterface>
>;
export type IScore = FormGroup<ControlsOf<IScoreInterface>>;
