import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { tap, catchError, of, BehaviorSubject, Observable } from 'rxjs';
import { AuthEndpoints } from '../constants/auth-constants';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthorizationService {

  private userSubject = new BehaviorSubject<any | null>(null);
  user$ = this.userSubject.asObservable().pipe();

  constructor(private http: HttpClient, private router: Router) { }

  getUser()  {
    return this.http.get<any>(AuthEndpoints.GET_USER).pipe(
      tap((res) => {
        this.userSubject.next(res);
      }),
      catchError(() => {
        this.router.navigate(['']);
        return of(null);
      }),
    );
  }
}
