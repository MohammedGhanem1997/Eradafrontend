import { Routes } from '@angular/router';
import { LayoutComponent } from './@block/@root/layout/layout.component';

export const routes: Routes = [
  {
    path: 'login',
    loadComponent: () =>
      import('./features/auth/login/login.component').then(
        (c) => c.LoginComponent
      ),
  },
  {
    path: 'first_time_login',
    loadComponent: () =>
      import(
        './features/auth/first-time-login/first-time-login.component'
      ).then((c) => c.FirstTimeLoginComponent),
  },
  {
    path: 'forget_password',
    loadComponent: () =>
      import('./features/auth/forget-password/forget-password.component').then(
        (c) => c.ForgetPasswordComponent
      ),
  },
  {
    path: 'need_help',
    loadComponent: () => import('./features/auth/components/need-help/need-help.component').then(c => c.NeedHelpComponent)
  },
  {
    path: '',
    component: LayoutComponent,
    children: [
      {
        path: '',
        loadComponent: () =>
          import('./features/landing/landing.component').then(
            (c) => c.LandingComponent
          ),
      },
      {
        path: 'products',
        loadComponent: () =>
          import('./features/products/products.component').then(
            (c) => c.ProductsComponent
          ),
      },
      {
        path: 'products/insurance-companies',
        loadComponent: () =>
          import(
            './features/products/components/insurance-companies/insurance-companies.component'
          ).then((c) => c.InsuranceCompaniesComponent),
      },
      {
        path: 'products/insurance-details/:id',
        loadComponent: () =>
          import(
            './features/products/pages/insurance-details/insurance-details.component'
          ).then((c) => c.InsuranceDetailsComponent),
      },
      {
        path: 'products/policy_details/:id',
        loadComponent: () => import('./features/products/pages/policy-details/policy-details.component').then(c => c.PolicyDetailsComponent)
      },
      {
        path: 'customers',
        loadComponent: () =>
          import('./features/customers/customers.component').then(
            (c) => c.CustomersComponent
          ),
      },
      {
        path: 'employees',
        loadComponent: () =>
          import('./features/employees/employees.component').then(
            (c) => c.EmployeesComponent
          ),
      },
      {
        path: 'employees/employee-details/:id',
        loadComponent: () =>
          import(
            './features/employees/components/employee-details/employee-details.component'
          ).then((c) => c.EmployeeDetailsComponent),
      },
      {
        path: 'employees/groups',
        loadComponent: () =>
          import('./features/employees/groups/groups.component').then(
            (c) => c.GroupsComponent
          ),
      },
      {
        path: 'employees/groups/group-details/:id',
        loadComponent: () =>
          import(
            './features/employees/groups/group-details/group-details.component'
          ).then((c) => c.GroupDetailsComponent),
      },

      {
        path: 'employees/roles',
        loadComponent: () =>
          import('./features/employees/roles/roles.component').then(
            (c) => c.RolesComponent
          ),
      },
      {
        path: 'employees/roles/role-details/:id',
        loadComponent: () =>
          import(
            './features/employees/roles/role-details/role-details.component'
          ).then((c) => c.RoleDetailsComponent),
      },
      {
        path: 'branches',
        loadComponent: () =>
          import('./features/branches/branches.component').then(
            (c) => c.BranchesComponent
          ),
      },
      {
        path: 'branches/branch-details/:id',
        loadComponent: () =>
          import(
            './features/branches/components/branch-details/branch-details.component'
          ).then((c) => c.BranchDetailsComponent),
      },
      {
        path: 'pending_requests',
        loadComponent: () =>
          import('./features/pending-request/pending-request.component').then(
            (c) => c.PendingRequestComponent
          ),
      },
      {
        path: '**',
        loadComponent: () =>
          import('./features/not-found/not-found.component').then(
            (c) => c.NotFoundComponent
          ),
      },
    ],
  },
];
